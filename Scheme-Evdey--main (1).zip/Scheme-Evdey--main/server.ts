import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { analyzeUserStory } from './src/lib/analyzer.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini if key exists
  const ai = process.env.GEMINI_API_KEY
    ? new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      })
    : null;

  // API Route: Analyze User Story
  app.post('/api/analyze', async (req, res) => {
    try {
      const { story } = req.body;
      if (!story || typeof story !== 'string') {
        return res.status(400).json({ error: 'Please provide a valid situation story text.' });
      }

      // Check if Gemini API key is available to generate dynamic report or fallback to rule engine
      if (ai && process.env.GEMINI_API_KEY) {
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-3.6-flash',
            contents: `You are JanMitra AI, an expert Kerala state and Indian central government welfare benefit discovery agent.
Analyze the following user life situation story and output a structured JSON analysis.

User Story: "${story}"

Return a valid JSON matching this structure:
{
  "benefitPotentialScore": number (0-100),
  "scoreLabel": string,
  "estimatedAnnualBenefitsRupees": number,
  "applicationsReadyCount": number,
  "missingDocsCount": number,
  "aiReasoningSummary": string,
  "extractedProfile": {
    "state": string,
    "district": string,
    "gender": string,
    "maritalStatus": string,
    "annualIncomeRupees": number,
    "dependentsCount": number,
    "childrenInSchool": number,
    "rationCardType": string,
    "occupation": string,
    "age": number
  },
  "schemes": [
    {
      "id": string,
      "title": string,
      "malayalamTitle": string,
      "department": string,
      "stateOrCentral": "Kerala State" | "Central Scheme" | "Kerala Joint (50:50)",
      "category": "pension" | "health" | "education" | "housing" | "livelihood" | "agriculture" | "women_child",
      "estimatedAnnualValue": number,
      "confidenceScore": number (0-100),
      "status": "ready_today" | "missing_docs" | "needs_verification",
      "shortSummary": string,
      "whyEligible": string[],
      "whyNotOrPending": string[],
      "citation": {
        "docName": string,
        "clauseNumber": string,
        "excerpt": string,
        "officialUrl": string
      },
      "requiredDocuments": string[],
      "howToApply": string,
      "officialPortalUrl": string
    }
  ],
  "documents": [
    {
      "id": string,
      "name": string,
      "malayalamName": string,
      "status": "ready" | "missing" | "easy_to_obtain",
      "requiredForSchemes": string[],
      "howToObtain": string,
      "issuingAuthority": string
    }
  ],
  "roadmap": [
    {
      "stepNumber": number,
      "title": string,
      "department": string,
      "actionRequired": string,
      "estimatedTime": string,
      "dependencies": string[],
      "associatedSchemes": string[],
      "priority": "Immediate" | "High" | "Medium" | "Low",
      "channel": "Akshaya Kendra" | "e-District Portal" | "Gram Panchayat / Municipality" | "School / College Office" | "Bank Branch"
    }
  ]
}

DO NOT wrap in markdown codeblocks if possible, or return raw json string. Ensure realism for Kerala state welfare policies.`,
            config: {
              responseMimeType: 'application/json'
            }
          });

          if (response.text) {
            const parsed = JSON.parse(response.text.trim());
            return res.json({
              reportId: `JM-AI-${Math.floor(100000 + Math.random() * 900000)}`,
              createdAt: new Date().toISOString(),
              userStory: story,
              ...parsed
            });
          }
        } catch (geminiError) {
          console.warn('Gemini AI call error, switching to fast rule-based engine:', geminiError);
        }
      }

      // Fast rule-based benchmark fallback
      const report = await analyzeUserStory(story);
      return res.json(report);
    } catch (err: any) {
      console.error('Error in /api/analyze:', err);
      return res.status(500).json({ error: 'Failed to analyze user situation.' });
    }
  });

  // Healthcheck endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'JanMitra AI Engine', timestamp: new Date().toISOString() });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JanMitra AI server running on http://localhost:${PORT}`);
  });
}

startServer();
