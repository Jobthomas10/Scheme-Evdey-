import React, { useState } from 'react';
import { BenefitReport, Scheme, UserProfileSummary } from './types';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { AnalysisLoading } from './components/AnalysisLoading';
import { ScoreCard } from './components/ScoreCard';
import { SchemeFilterTabs } from './components/SchemeFilterTabs';
import { SchemeCard } from './components/SchemeCard';
import { RoadmapTimeline } from './components/RoadmapTimeline';
import { DocumentChecklist } from './components/DocumentChecklist';
import { ClarifyingModal } from './components/ClarifyingModal';
import { ExportModal } from './components/ExportModal';
import { SchemeDetailsModal } from './components/SchemeDetailsModal';
import { MySchemesTab } from './components/MySchemesTab';
import { ProfileTab } from './components/ProfileTab';
import { Footer } from './components/Footer';
import { CLARIFYING_QUESTIONS, DEFAULT_KERALA_WIDOW_REPORT } from './data/mockData';
import { Sparkles, FileText, RotateCcw, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<'en' | 'ml'>('en');
  const [viewState, setViewState] = useState<'landing' | 'loading' | 'report'>('landing');
  const [headerNavTab, setHeaderNavTab] = useState<'dashboard' | 'my_schemes' | 'profile'>('dashboard');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [report, setReport] = useState<BenefitReport | null>(null);
  
  // Filtering & Bookmarks
  const [activeTab, setActiveTab] = useState<string>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(['sch-suvarna-jubilee', 'sch-pmay-life']);

  // Modals
  const [selectedSchemeForModal, setSelectedSchemeForModal] = useState<Scheme | null>(null);
  const [showClarifying, setShowClarifying] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAnalyzeStory = async (storyText: string) => {
    setViewState('loading');
    setIsAnalyzing(true);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ story: storyText }),
      });

      if (!res.ok) {
        throw new Error('Analysis endpoint returned error');
      }

      const data: BenefitReport = await res.json();
      setReport(data);
    } catch (err) {
      console.warn('API error, using client-side fallback engine:', err);
      const { analyzeUserStory } = await import('./lib/analyzer');
      const fallbackReport = await analyzeUserStory(storyText);
      setReport(fallbackReport);
    } fontFinally: {
      setIsAnalyzing(false);
    }
  };

  const handleLoadingComplete = () => {
    setViewState('report');
    setHeaderNavTab('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast(lang === 'en' ? 'Family Benefit Report Generated!' : 'റിപ്പോർട്ട് തയ്യാറായി!');
  };

  const handleStartOver = () => {
    setViewState('landing');
    setHeaderNavTab('dashboard');
    setReport(null);
    setActiveTab('all');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds(prev => {
      const isSaved = prev.includes(id);
      if (isSaved) {
        showToast(lang === 'en' ? 'Scheme removed from bookmarks' : 'പദ്ധതി ഒഴിവാക്കി');
        return prev.filter(i => i !== id);
      } else {
        showToast(lang === 'en' ? 'Scheme saved to bookmarks' : 'പദ്ധതി സേവ് ചെയ്തു');
        return [...prev, id];
      }
    });
  };

  const handleAnswerClarifying = (opt: { label: string; value: string; impactOnScore: string }) => {
    setShowClarifying(false);
    const targetReport = report || DEFAULT_KERALA_WIDOW_REPORT;
    const updatedScore = Math.min(100, targetReport.benefitPotentialScore + 4);
    setReport({
      ...targetReport,
      benefitPotentialScore: updatedScore,
      scoreLabel: updatedScore >= 95 ? 'Maximum Certified Eligibility' : 'Very High Scheme Eligibility',
      aiReasoningSummary: `${targetReport.aiReasoningSummary} [Verified: ${opt.label} (${opt.impactOnScore})].`
    });
    showToast(lang === 'en' ? `Score refined to ${updatedScore}/100!` : `സ്കോർ ${updatedScore} ലേക്ക് ഉയർന്നു!`);
  };

  // Helper to open scheme detail modal
  const handleOpenSchemeModalById = (schemeId: string) => {
    const allSchemes = report ? report.schemes : DEFAULT_KERALA_WIDOW_REPORT.schemes;
    const found = allSchemes.find(s => s.id === schemeId);
    if (found) {
      setSelectedSchemeForModal(found);
    } else {
      // Create a fallback Suvarna Jubilee Scheme if needed
      setSelectedSchemeForModal({
        id: 'sch-suvarna-jubilee',
        title: 'Suvarna Jubilee Merit Scholarship',
        malayalamTitle: 'സുവർണ്ണജൂബിലി മെറിറ്റ് സ്കോളർഷിപ്പ്',
        department: 'Department of Collegiate Education, Kerala State',
        stateOrCentral: 'Kerala State',
        category: 'education',
        estimatedAnnualValue: 10000,
        confidenceScore: 85,
        status: 'missing_docs',
        shortSummary: 'Financial assistance to needy students pursuing first year under-graduate or post-graduate courses in Government/Aided colleges.',
        whyEligible: [
          'Student Status: Confirmed enrollment in Government Aided College.',
          'Income Criteria: Family income below ₹1,00,000 per annum (Statutory Limit).',
          'Merit Qualification: Scored above 50% in the qualifying examination.'
        ],
        whyNotOrPending: [
          'Income Certificate and Institution Verification Pending.'
        ],
        citation: {
          docName: 'Govt of Kerala Collegiate Education Gazette 2024-25',
          clauseNumber: 'Rule 3.1 - Merit Scholarship Criteria',
          excerpt: 'A merit scholarship of ₹10,000 per year shall be awarded to eligible BPL student candidates admitted to degree courses.',
          officialUrl: 'https://dcekerala.gov.in'
        },
        requiredDocuments: [
          'Digital Income Certificate',
          'College Admission Receipt',
          'Mark List of Qualifying Exam'
        ],
        howToApply: 'Online application via DCE Portal and hard copy submission to College Office.',
        officialPortalUrl: 'https://dcekerala.gov.in'
      });
    }
  };

  // Filter schemes based on active tab
  const getFilteredSchemes = () => {
    if (!report) return [];
    if (activeTab === 'all') return report.schemes;
    if (activeTab === 'high_confidence') return report.schemes.filter(s => s.confidenceScore >= 90);
    if (activeTab === 'ready_today') return report.schemes.filter(s => s.status === 'ready_today');
    return report.schemes.filter(s => s.category === activeTab);
  };

  const filteredSchemes = getFilteredSchemes();

  // Get saved schemes list
  const currentSchemes = report ? report.schemes : DEFAULT_KERALA_WIDOW_REPORT.schemes;
  const savedSchemesList = currentSchemes.filter(s => bookmarkedIds.includes(s.id));

  // Current Profile
  const currentProfile = report ? report.extractedProfile : DEFAULT_KERALA_WIDOW_REPORT.extractedProfile;

  const handleUpdateProfile = (updatedProfile: UserProfileSummary) => {
    if (report) {
      setReport({
        ...report,
        extractedProfile: updatedProfile
      });
    }
    showToast(lang === 'en' ? 'Profile updated successfully' : 'പ്രൊഫൈൽ പുതുക്കി');
  };

  return (
    <div className="min-h-screen bg-[#f8faf9] dark:bg-slate-950 text-[#191c1e] dark:text-slate-100 font-sans flex flex-col selection:bg-[#00685f] selection:text-white">
      
      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-[#191c1e] text-white px-4 py-2.5 rounded-2xl border border-[#00685f]/40 shadow-xl text-xs font-bold flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Persistent Header */}
      <Header
        onStartOver={handleStartOver}
        lang={lang}
        setLang={setLang}
        hasReport={viewState === 'report' && !!report}
        onOpenExport={() => setShowExportModal(true)}
        activeTab={headerNavTab}
        setActiveTab={(tab) => {
          setHeaderNavTab(tab);
          if (tab === 'dashboard' && viewState === 'report') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }}
        savedSchemesCount={bookmarkedIds.length}
      />

      {/* Page Content Router */}
      <main className="flex-1">
        
        {/* NAV TAB 2: MY SCHEMES */}
        {headerNavTab === 'my_schemes' && (
          <MySchemesTab
            savedSchemes={savedSchemesList}
            lang={lang}
            onSelectScheme={(scheme) => setSelectedSchemeForModal(scheme)}
            onRemoveBookmark={(id) => handleToggleBookmark(id)}
            onNavigateHome={() => setHeaderNavTab('dashboard')}
          />
        )}

        {/* NAV TAB 3: PROFILE */}
        {headerNavTab === 'profile' && (
          <ProfileTab
            profile={currentProfile}
            onUpdateProfile={handleUpdateProfile}
            lang={lang}
          />
        )}

        {/* NAV TAB 1: DASHBOARD / LANDING */}
        {headerNavTab === 'dashboard' && (
          <>
            {/* VIEW 1: LANDING */}
            {viewState === 'landing' && (
              <HeroSection
                onSubmitStory={handleAnalyzeStory}
                lang={lang}
                isAnalyzing={isAnalyzing}
                onSelectScheme={(id) => handleOpenSchemeModalById(id)}
                onViewAllSchemes={() => {
                  handleAnalyzeStory("I am looking for all Kerala state and central government welfare schemes.");
                }}
              />
            )}

            {/* VIEW 2: LOADING ANALYSIS */}
            {viewState === 'loading' && (
              <AnalysisLoading
                onComplete={handleLoadingComplete}
                lang={lang}
              />
            )}

            {/* VIEW 3: FAMILY BENEFIT REPORT */}
            {viewState === 'report' && report && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-fade-in">
                
                {/* Visual & Emotional Centerpiece: ScoreCard */}
                <ScoreCard
                  report={report}
                  lang={lang}
                  onRefineScoreClick={() => setShowClarifying(true)}
                />

                {/* Main Content Layout Grid */}
                <div className="space-y-10">
                  
                  {/* SECTION 1: Priority Schemes List */}
                  <div id="priority-schemes-section">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                      <div>
                        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                          {lang === 'en' ? 'Matched Welfare Schemes' : 'നിങ്ങൾക്ക് ലഭ്യമായ പദ്ധതിക‌ൾ'}
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                          {lang === 'en' ? 'Ranked by confidence score and estimated annual value.' : 'വിശ്വാസ്യതയുടെ അടിസ്ഥാനത്തിൽ ക്രമീകരിച്ചത്.'}
                        </p>
                      </div>

                      <span className="text-xs font-bold text-[#00685f] dark:text-teal-400 bg-[#00685f]/10 px-3 py-1 rounded-full border border-[#00685f]/20 self-start sm:self-auto">
                        {filteredSchemes.length} Schemes Available
                      </span>
                    </div>

                    {/* Filter Pills */}
                    <SchemeFilterTabs
                      activeTab={activeTab}
                      setActiveTab={setActiveTab}
                      lang={lang}
                      schemesCount={report.schemes.length}
                    />

                    {/* Scheme Cards Grid */}
                    <div className="grid grid-cols-1 gap-6">
                      {filteredSchemes.map((scheme) => (
                        <div key={scheme.id} className="relative group">
                          <SchemeCard
                            scheme={scheme}
                            lang={lang}
                            onBookmarked={handleToggleBookmark}
                            isBookmarked={bookmarkedIds.includes(scheme.id)}
                          />
                          <button
                            onClick={() => setSelectedSchemeForModal(scheme)}
                            className="absolute bottom-6 right-6 px-4 py-2 rounded-xl bg-[#00685f]/10 hover:bg-[#00685f] text-[#00685f] hover:text-white font-bold text-xs transition-all cursor-pointer hidden sm:block"
                          >
                            View Full Details →
                          </button>
                        </div>
                      ))}

                      {filteredSchemes.length === 0 && (
                        <div className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-8 text-center text-slate-500">
                          <p className="text-sm font-semibold">No schemes match this category filter.</p>
                          <button
                            onClick={() => setActiveTab('all')}
                            className="mt-2 text-xs text-[#00685f] font-bold underline cursor-pointer"
                          >
                            Show All Matched Schemes
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* SECTION 2: Application Roadmap Timeline */}
                  <RoadmapTimeline
                    roadmap={report.roadmap}
                    lang={lang}
                  />

                  {/* SECTION 3: Missing Documents Checklist */}
                  <DocumentChecklist
                    documents={report.documents}
                    lang={lang}
                  />

                </div>

                {/* Bottom Floating Bar */}
                <div className="sticky bottom-6 z-30 max-w-lg mx-auto bg-[#191c1e]/90 backdrop-blur-md border border-slate-800 rounded-2xl p-3 shadow-2xl flex items-center justify-between text-white text-xs">
                  <div className="flex items-center space-x-2 pl-2">
                    <Sparkles className="w-4 h-4 text-teal-400" />
                    <span className="font-bold">{report.benefitPotentialScore}% Potential Score</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setShowExportModal(true)}
                      className="px-4 py-2 rounded-xl bg-[#00685f] hover:bg-[#00514a] text-white font-extrabold transition-all shadow-xs flex items-center space-x-1.5 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Download Report</span>
                    </button>

                    <button
                      onClick={handleStartOver}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition-colors cursor-pointer"
                      title="Start Over"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            )}
          </>
        )}

      </main>

      {/* Scheme Detailed View Modal (Screen 3 in prompt image!) */}
      {selectedSchemeForModal && (
        <SchemeDetailsModal
          scheme={selectedSchemeForModal}
          onClose={() => setSelectedSchemeForModal(null)}
          lang={lang}
          onUploadDoc={(doc) => {
            showToast(`Uploading digital copy of ${doc}...`);
          }}
        />
      )}

      {/* Clarifying Modal */}
      {showClarifying && (
        <ClarifyingModal
          question={CLARIFYING_QUESTIONS[0]}
          onAnswer={handleAnswerClarifying}
          onSkip={() => setShowClarifying(false)}
          lang={lang}
        />
      )}

      {/* Export / Print Modal */}
      {showExportModal && report && (
        <ExportModal
          report={report}
          onClose={() => setShowExportModal(false)}
          lang={lang}
        />
      )}

      {/* Persistent Footer */}
      <Footer lang={lang} />

    </div>
  );
}
