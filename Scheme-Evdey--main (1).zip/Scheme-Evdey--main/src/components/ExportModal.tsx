import React, { useState } from 'react';
import { BenefitReport } from '../types';
import { Printer, Download, Copy, Check, X, ShieldCheck, FileText, Share2 } from 'lucide-react';

interface ExportModalProps {
  report: BenefitReport;
  onClose: () => void;
  lang: 'en' | 'ml';
}

export const ExportModal: React.FC<ExportModalProps> = ({ report, onClose, lang }) => {
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopySummary = () => {
    const text = `JanMitra AI Family Benefit Report (${report.reportId})
Benefit Potential Score: ${report.benefitPotentialScore}/100
Estimated Annual Value: ₹${report.estimatedAnnualBenefitsRupees.toLocaleString('en-IN')}
Ready Applications: ${report.applicationsReadyCount}
Missing Certificates: ${report.missingDocsCount}

Matched Schemes:
${report.schemes.map(s => `- ${s.title} (Est. ₹${s.estimatedAnnualValue.toLocaleString('en-IN')}/yr)`).join('\n')}

Generated on JanMitra AI - Grounded in Kerala Welfare Gazettes.`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(report, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `JanMitra_Report_${report.reportId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#191c1e]/60 backdrop-blur-xs animate-fade-in">
      <div className="max-w-lg w-full bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-900 dark:text-white relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-[#f2f4f6] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 text-[#505f76] dark:text-slate-400 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-[#00685f]/10 text-[#00685f] dark:text-teal-400 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              {lang === 'en' ? 'Download & Export Report' : 'റിപ്പോർട്ട് ഡൗൺലോഡ് ചെയ്യുക'}
            </h3>
            <p className="text-xs text-[#505f76] dark:text-slate-400 font-mono font-semibold">Report ID: {report.reportId}</p>
          </div>
        </div>

        {/* Report Card Preview */}
        <div className="bg-[#f7f9fb] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-4 my-4 space-y-2 text-xs font-medium">
          <div className="flex justify-between items-center pb-2 border-b border-[#e0e3e5] dark:border-slate-800 text-slate-700 dark:text-slate-300">
            <span>Score: <strong className="text-[#00685f] dark:text-teal-400 font-extrabold">{report.benefitPotentialScore}/100</strong></span>
            <span>Est. Benefits: <strong className="text-[#00685f] dark:text-emerald-400 font-extrabold">₹{report.estimatedAnnualBenefitsRupees.toLocaleString('en-IN')}/yr</strong></span>
          </div>
          <p className="text-[#505f76] dark:text-slate-400 line-clamp-2 italic">
            "{report.userStory}"
          </p>
        </div>

        {/* Action Grid */}
        <div className="space-y-3 my-6">
          <button
            onClick={handlePrint}
            className="w-full py-3.5 px-4 rounded-xl bg-[#00685f] hover:bg-[#00514a] text-white font-extrabold text-sm shadow-xs transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{lang === 'en' ? 'Print / Save as PDF' : 'പിഡിഎഫ് ആകുക'}</span>
          </button>

          <button
            onClick={handleCopySummary}
            className="w-full py-3.5 px-4 rounded-xl bg-[#f2f4f6] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 text-[#191c1e] dark:text-slate-200 font-bold text-sm transition-all flex items-center justify-center space-x-2 border border-[#e0e3e5] dark:border-slate-700 cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-[#00685f]" /> : <Copy className="w-4 h-4 text-[#00685f]" />}
            <span>{copied ? (lang === 'en' ? 'Copied to Clipboard!' : 'പകർത്തി!') : (lang === 'en' ? 'Copy Text Summary' : 'ടെക്സ്റ്റ് പകർപ്പ എടുക്കുക')}</span>
          </button>

          <button
            onClick={handleDownloadJSON}
            className="w-full py-3.5 px-4 rounded-xl bg-[#f2f4f6] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 text-[#191c1e] dark:text-slate-200 font-bold text-sm transition-all flex items-center justify-center space-x-2 border border-[#e0e3e5] dark:border-slate-700 cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#00685f]" />
            <span>{lang === 'en' ? 'Export Offline JSON' : 'ജെസൺ ഫയൽ ഡൗൺലോഡ് ചെയ്യുക'}</span>
          </button>
        </div>

        <div className="text-[11px] text-[#505f76] dark:text-slate-400 text-center flex items-center justify-center gap-1 font-semibold">
          <ShieldCheck className="w-3.5 h-3.5 text-[#00685f]" />
          <span>Official JanMitra AI Advisory Document</span>
        </div>

      </div>
    </div>
  );
};

