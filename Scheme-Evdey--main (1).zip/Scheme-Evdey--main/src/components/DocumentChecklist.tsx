import React, { useState } from 'react';
import { DocumentItem } from '../types';
import { CheckCircle2, FileQuestion, FileCheck, Building, HelpCircle, AlertCircle, Info } from 'lucide-react';

interface DocumentChecklistProps {
  documents: DocumentItem[];
  lang: 'en' | 'ml';
}

export const DocumentChecklist: React.FC<DocumentChecklistProps> = ({ documents, lang }) => {
  const [docStates, setDocStates] = useState<Record<string, 'ready' | 'missing' | 'easy_to_obtain'>>(
    () => {
      const initial: Record<string, 'ready' | 'missing' | 'easy_to_obtain'> = {};
      documents.forEach(doc => {
        initial[doc.id] = doc.status;
      });
      return initial;
    }
  );

  const toggleStatus = (id: string) => {
    setDocStates(prev => {
      const current = prev[id];
      const next = current === 'ready' ? 'missing' : 'ready';
      return { ...prev, [id]: next };
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ready':
        return {
          label: lang === 'en' ? 'Ready with You' : 'കയ്യിലുള്ളത്',
          bg: 'bg-[#00685f]/10 text-[#00685f] border-[#00685f]/20',
          icon: CheckCircle2
        };
      case 'easy_to_obtain':
        return {
          label: lang === 'en' ? 'Easy to Obtain' : 'എളുപ്പത്തിൽ ലഭിക്കുന്നത്',
          bg: 'bg-teal-500/10 text-teal-700 border-teal-500/20',
          icon: Info
        };
      default:
        return {
          label: lang === 'en' ? 'Missing - Action Needed' : 'ഹാജരാക്കേണ്ടവ',
          bg: 'bg-[#ba1a1a]/10 text-[#ba1a1a] border-[#ba1a1a]/20',
          icon: AlertCircle
        };
    }
  };

  const readyCount = Object.values(docStates).filter(s => s === 'ready').length;

  return (
    <div id="missing-documents-checklist" className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs mb-10">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#e0e3e5] dark:border-slate-800 mb-6">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#00685f] dark:text-teal-400">
              {lang === 'en' ? 'Certificate Preparedness' : 'സർട്ടിഫിക്കറ്റ് പരിശോധന'}
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {lang === 'en' ? 'Missing Documents & Certificates Checklist' : 'രേഖകളുടെ ചെക്ക് ലിസ്റ്റ്'}
          </h3>
          <p className="text-xs text-[#505f76] dark:text-slate-400 mt-1 font-medium">
            {lang === 'en'
              ? 'Click to check off certificates as you acquire them from Akshaya Kendra or Village Office.'
              : 'സർട്ടിഫിക്കറ്റുകൾ തയ്യാറാകുമ്പോൾ ഇവിടെ ക്ലിക്ക് ചെയ്യുക.'}
          </p>
        </div>

        {/* Preparedness Progress Badge */}
        <div className="bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 px-4 py-2.5 rounded-2xl text-right shadow-2xs">
          <span className="text-[10px] font-bold uppercase text-[#505f76] block">Readiness</span>
          <span className="text-lg font-black text-[#00685f] dark:text-teal-400">
            {readyCount} / {documents.length} Ready
          </span>
        </div>
      </div>

      {/* Document Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documents.map((doc) => {
          const currentStatus = docStates[doc.id] || doc.status;
          const statusInfo = getStatusBadge(currentStatus);
          const IconComp = statusInfo.icon;
          const isReady = currentStatus === 'ready';

          return (
            <div
              key={doc.id}
              onClick={() => toggleStatus(doc.id)}
              className={`p-5 rounded-2xl border cursor-pointer transition-all duration-300 flex flex-col justify-between hover-lift ${
                isReady
                  ? 'bg-[#00685f]/5 border-[#00685f]/30 shadow-2xs'
                  : 'bg-[#f7f9fb] dark:bg-slate-950 border-[#e0e3e5] dark:border-slate-800 hover:border-[#00685f]'
              }`}
            >
              <div>
                {/* Status Bar */}
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${statusInfo.bg}`}>
                    <IconComp className="w-3.5 h-3.5" />
                    <span>{statusInfo.label}</span>
                  </span>

                  <span className="text-[10px] text-[#505f76] font-mono font-semibold">
                    Issuing: {doc.issuingAuthority}
                  </span>
                </div>

                {/* Doc Name */}
                <h4 className={`text-base font-black ${isReady ? 'text-[#00685f] dark:text-teal-300 line-through opacity-80' : 'text-slate-900 dark:text-white'}`}>
                  {doc.name}
                </h4>
                {doc.malayalamName && (
                  <p className="text-xs font-bold text-[#00685f] dark:text-teal-400 mt-0.5">
                    {doc.malayalamName}
                  </p>
                )}

                {/* Required For Schemes */}
                <div className="mt-2 text-[11px] text-[#505f76] dark:text-slate-400 font-medium">
                  <span className="font-bold text-slate-700 dark:text-slate-300">Required for: </span>
                  <span>{doc.requiredForSchemes.join(', ')}</span>
                </div>
              </div>

              {/* How to Obtain Instructions */}
              <div className="mt-4 pt-3 border-t border-[#e0e3e5] dark:border-slate-800 text-xs text-[#505f76] dark:text-slate-400 font-medium">
                <span className="font-bold text-slate-800 dark:text-slate-200">How to get: </span>
                <span>{doc.howToObtain}</span>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};

