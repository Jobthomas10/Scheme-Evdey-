import React from 'react';
import { Layers, Sparkles, Zap, HeartPulse, GraduationCap, Shield, Home, Briefcase } from 'lucide-react';

interface SchemeFilterTabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: 'en' | 'ml';
  schemesCount: number;
}

export const SchemeFilterTabs: React.FC<SchemeFilterTabsProps> = ({
  activeTab,
  setActiveTab,
  lang,
  schemesCount
}) => {
  const tabs = [
    { id: 'all', label: lang === 'en' ? 'All Matched Schemes' : 'എല്ലാ പദ്ധതികളും', icon: Layers },
    { id: 'high_confidence', label: lang === 'en' ? '90%+ Confidence' : 'ഉയർന്ന ഉറപ്പുള്ളവ', icon: Sparkles },
    { id: 'ready_today', label: lang === 'en' ? 'Ready Today' : 'അടിയന്തര അപേക്ഷ', icon: Zap },
    { id: 'pension', label: lang === 'en' ? 'Pensions' : 'പെൻഷൻ', icon: Shield },
    { id: 'education', label: lang === 'en' ? 'Education' : 'വിദ്യാഭ്യാസം', icon: GraduationCap },
    { id: 'health', label: lang === 'en' ? 'Health' : 'ആരോഗ്യം', icon: HeartPulse },
    { id: 'housing', label: lang === 'en' ? 'Housing' : 'ഭവന സഹായം', icon: Home },
    { id: 'livelihood', label: lang === 'en' ? 'Livelihood' : 'തൊഴിൽ', icon: Briefcase }
  ];

  return (
    <div id="scheme-filter-tabs" className="flex items-center space-x-2 overflow-x-auto pb-3 mb-6 scrollbar-none">
      <div className="flex items-center space-x-2 min-w-max p-1 bg-[#eceef0] dark:bg-slate-800 rounded-2xl border border-[#e0e3e5] dark:border-slate-700">
        {tabs.map((tab) => {
          const IconComp = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center space-x-1.5 cursor-pointer ${
                isActive
                  ? 'bg-white dark:bg-slate-900 text-[#00685f] dark:text-teal-300 shadow-sm border border-[#bcc9c6] dark:border-slate-700'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50'
              }`}
            >
              <IconComp className={`w-3.5 h-3.5 ${isActive ? 'text-[#00685f]' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
              {tab.id === 'all' && (
                <span className="ml-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-[#00685f]/10 text-[#00685f] dark:text-teal-300">
                  {schemesCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

