import React from 'react';
import { RoadmapStep } from '../types';
import { Clock, Layers, ArrowRight, Building, CheckCircle, AlertTriangle } from 'lucide-react';

interface RoadmapTimelineProps {
  roadmap: RoadmapStep[];
  lang: 'en' | 'ml';
}

export const RoadmapTimeline: React.FC<RoadmapTimelineProps> = ({ roadmap, lang }) => {
  return (
    <div id="application-roadmap-section" className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs mb-10">
      
      {/* Title Header */}
      <div className="flex items-center justify-between pb-6 border-b border-[#e0e3e5] dark:border-slate-800 mb-8">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#00685f] dark:text-teal-400">
              {lang === 'en' ? 'Step-by-Step Filing Order' : 'അപേക്ഷാ ക്രമം'}
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {lang === 'en' ? 'Application Roadmap & Dependencies' : 'അപേക്ഷാ റോഡ്മാപ്പ്'}
          </h3>
          <p className="text-xs text-[#505f76] dark:text-slate-400 mt-1 font-medium">
            {lang === 'en'
              ? 'Complete prerequisites in this recommended order to avoid document rejection.'
              : 'സർട്ടിഫിക്കറ്റുകൾ നിരസിക്കപ്പെടാതിരിക്കാൻ ഈ ക്രമത്തിൽ അപേക്ഷിക്കുക.'}
          </p>
        </div>

        <div className="hidden sm:flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border border-[#00685f]/20 text-xs font-bold">
          <Layers className="w-3.5 h-3.5 text-[#00685f]" />
          <span>{roadmap.length} Milestone Steps</span>
        </div>
      </div>

      {/* Vertical Timeline List */}
      <div className="relative pl-6 sm:pl-10 space-y-8 before:absolute before:left-3 sm:before:left-5 before:top-3 before:bottom-3 before:w-0.5 before:bg-[#00685f]/30 dark:before:bg-slate-700">
        
        {roadmap.map((step) => {
          const isImmediate = step.priority === 'Immediate';

          return (
            <div key={step.stepNumber} className="relative group">
              
              {/* Numbered Circular Badge on Timeline Line */}
              <div className={`absolute -left-6 sm:-left-10 top-0 w-8 h-8 sm:w-10 sm:h-10 rounded-full font-extrabold text-sm flex items-center justify-center border-2 shadow-xs transition-transform group-hover:scale-105 ${
                isImmediate
                  ? 'bg-[#00685f] text-white border-[#00685f] shadow-md shadow-[#00685f]/20'
                  : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border-[#bcc9c6] dark:border-slate-700'
              }`}>
                {step.stepNumber}
              </div>

              {/* Step Detail Card */}
              <div className="bg-[#f7f9fb] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-5 hover:border-[#00685f]/40 transition-all hover-lift">
                
                {/* Step Top Bar: Dept + Time + Channel */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-bold text-[#3d4947] dark:text-slate-300 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-[#00685f] dark:text-teal-400" />
                    {step.department}
                  </span>

                  <div className="flex items-center space-x-2">
                    {/* Time estimate */}
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 px-3 py-0.5 rounded-full border border-[#e0e3e5] dark:border-slate-700 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-500" />
                      {step.estimatedTime}
                    </span>

                    {/* Priority Tag */}
                    <span className={`text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                      isImmediate
                        ? 'bg-[#ba1a1a]/10 text-[#ba1a1a] dark:text-rose-300 border-[#ba1a1a]/20'
                        : 'bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border-[#00685f]/20'
                    }`}>
                      {step.priority}
                    </span>
                  </div>
                </div>

                {/* Step Title */}
                <h4 className="text-base sm:text-lg font-black text-slate-900 dark:text-white mb-2">
                  {step.title}
                </h4>

                {/* Action Required text */}
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium leading-relaxed mb-4 bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-[#e0e3e5] dark:border-slate-800">
                  {step.actionRequired}
                </p>

                {/* Dependencies + Channel Tag */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#e0e3e5] dark:border-slate-800 text-xs">
                  
                  {/* Prerequisite Dependencies */}
                  <div className="flex items-center space-x-1.5 flex-wrap">
                    <span className="font-bold text-[#505f76] dark:text-slate-400 text-[11px] uppercase tracking-wider">
                      Prerequisites:
                    </span>
                    {step.dependencies.map((dep, dIdx) => (
                      <span
                        key={dIdx}
                        className="bg-[#eceef0] dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-[#e0e3e5] dark:border-slate-700"
                      >
                        {dep}
                      </span>
                    ))}
                  </div>

                  {/* Channel Tag */}
                  <span className="font-bold text-[#00685f] dark:text-teal-300 bg-[#00685f]/10 px-3 py-1 rounded-full border border-[#00685f]/20 text-[11px]">
                    Channel: {step.channel}
                  </span>

                </div>

              </div>

            </div>
          );
        })}

      </div>

    </div>
  );
};

