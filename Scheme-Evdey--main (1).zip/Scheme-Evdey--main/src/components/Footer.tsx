import React from 'react';
import { ShieldCheck, ExternalLink, Heart, AlertCircle, PhoneCall } from 'lucide-react';

interface FooterProps {
  lang: 'en' | 'ml';
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  return (
    <footer id="main-footer" className="bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-t border-[#e0e3e5] dark:border-slate-800 pt-12 pb-8 px-4 sm:px-6 lg:px-8 text-xs">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
        
        {/* Col 1: Brand & Purpose */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-[#00685f] text-white flex items-center justify-center font-bold shadow-xs">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-[#191c1e] dark:text-white text-base tracking-tight">JanMitra AI</span>
          </div>
          <p className="text-[#505f76] dark:text-slate-400 leading-relaxed max-w-md font-medium">
            {lang === 'en'
              ? 'An AI-powered welfare discovery initiative helping Kerala residents and families identify entitled state and central welfare schemes with clause-level clarity.'
              : 'കേരളത്തിലെ കുടുംബങ്ങൾക്ക് അർഹമായ വിവരങ്ങളും ആനുകൂല്യങ്ങളും എളുപ്പത്തിൽ കണ്ടെത്താനുള്ള സർട്ടിഫൈഡ് AI പ്ലാറ്റ്‌ഫോം.'}
          </p>
          <div className="flex items-center space-x-2 text-xs font-bold text-[#00685f] dark:text-teal-400">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Akshaya Toll-Free Helpdesk: 155300 / 0471-2330510</span>
          </div>
        </div>

        {/* Col 2: Official Portals */}
        <div className="space-y-2">
          <h4 className="font-extrabold text-[#191c1e] dark:text-white uppercase text-[11px] tracking-wider">Official Portals</h4>
          <ul className="space-y-2 text-[#505f76] dark:text-slate-400 font-medium">
            <li>
              <a href="https://edistrict.kerala.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#00685f] dark:hover:text-teal-300 transition-colors inline-flex items-center gap-1">
                <span>Kerala e-District Portal</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </li>
            <li>
              <a href="https://welfarepension.lsgkerala.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#00685f] dark:hover:text-teal-300 transition-colors inline-flex items-center gap-1">
                <span>Sevana Pension Portal</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </li>
            <li>
              <a href="https://sha.kerala.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#00685f] dark:hover:text-teal-300 transition-colors inline-flex items-center gap-1">
                <span>KASP Health Agency</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </li>
            <li>
              <a href="https://akshaya.kerala.gov.in" target="_blank" rel="noreferrer" className="hover:text-[#00685f] dark:hover:text-teal-300 transition-colors inline-flex items-center gap-1">
                <span>Akshaya Kendra Services</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </li>
          </ul>
        </div>

        {/* Col 3: Disclaimer Box */}
        <div className="p-4 rounded-2xl bg-[#f2f4f6] dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 space-y-2">
          <div className="flex items-center space-x-1.5 text-amber-600 font-bold text-[11px]">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>Official Disclaimer</span>
          </div>
          <p className="text-[11px] text-[#505f76] dark:text-slate-400 leading-relaxed font-medium">
            {lang === 'en'
              ? 'This is an advisory tool. Final eligibility is determined by the respective government departments.'
              : 'ഇതൊരു നിർദ്ദേശാത്മക സഹായ സംവിധാനമാണ്. അന്തിമ അർഹത ബന്ധപ്പെട്ട സർക്കാർ വകുപ്പുകൾ നിശ്ചയിക്കുന്നതാണ്.'}
          </p>
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-[#e0e3e5] dark:border-slate-900 flex flex-col sm:flex-row items-center justify-between text-[#505f76] dark:text-slate-500 text-[11px] font-semibold">
        <p>© 2026 JanMitra AI • Empowering Citizens with Transparent Benefit Discovery</p>
        <p className="mt-2 sm:mt-0 flex items-center gap-1">
          Made for Kerala State Welfare <Heart className="w-3 h-3 text-[#ba1a1a] fill-[#ba1a1a]" />
        </p>
      </div>
    </footer>
  );
};

