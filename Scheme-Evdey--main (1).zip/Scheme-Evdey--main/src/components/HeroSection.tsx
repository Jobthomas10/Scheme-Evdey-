import React, { useState, useEffect } from 'react';
import { SAMPLE_PRESET_STORIES } from '../data/mockData';
import { Search, Sparkles, ShieldCheck, Lock, ArrowRight, Lightbulb, Globe, CheckCircle2, TrendingUp, Layers, Bell, ExternalLink, GraduationCap, Home, Sprout } from 'lucide-react';

interface HeroSectionProps {
  onSubmitStory: (story: string) => void;
  lang: 'en' | 'ml';
  isAnalyzing: boolean;
  onSelectScheme?: (schemeId: string) => void;
  onViewAllSchemes?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSubmitStory,
  lang,
  isAnalyzing,
  onSelectScheme,
  onViewAllSchemes
}) => {
  const [inputStory, setInputStory] = useState<string>(
    "I am a student with no income looking for educational scholarships and health cover in Kerala."
  );
  const [newsletterInput, setNewsletterInput] = useState<string>('');
  const [subscribed, setSubscribed] = useState<boolean>(false);

  // Counter animation for Citizens Helped
  const [citizensCount, setCitizensCount] = useState<number>(0);
  useEffect(() => {
    let count = 0;
    const target = 12480;
    const interval = setInterval(() => {
      count += 312;
      if (count >= target) {
        setCitizensCount(target);
        clearInterval(interval);
      } else {
        setCitizensCount(count);
      }
    }, 30);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputStory.trim()) return;
    onSubmitStory(inputStory);
  };

  const handleChipClick = (promptText: string) => {
    setInputStory(promptText);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterInput) return;
    setSubscribed(true);
    setNewsletterInput('');
  };

  return (
    <div id="hero-section" className="relative overflow-hidden bg-[#f8faf9] dark:bg-slate-950 text-[#191c1e] dark:text-white py-12 sm:py-16 px-4 sm:px-6 lg:px-8">
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 -mr-32 -mt-32 w-[600px] h-[600px] bg-[#00685f]/5 rounded-full blur-3xl -z-10 pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-32 -mb-32 w-[400px] h-[400px] bg-[#505f76]/5 rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10 text-center">
        
        {/* Badge Label */}
        <div className="animate-fade-in-up inline-flex items-center space-x-2 px-4 py-1.5 bg-[#eceef0] dark:bg-slate-800 rounded-full mb-6 border border-[#e0e3e5] dark:border-slate-700">
          <Sparkles className="w-3.5 h-3.5 text-[#00685f] dark:text-teal-400" />
          <span className="text-xs font-bold text-[#3d4947] dark:text-slate-300 uppercase tracking-widest">
            {lang === 'en' 
              ? '✦ KERALA STATE + CENTRAL GOVERNMENT ENGINE' 
              : '✦ കേരള സംസ്ഥാന + കേന്ദ്ര വികസന ഏജൻസി'}
          </span>
        </div>

        {/* Main Headline */}
        <h1 className="animate-fade-in-up stagger-1 text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#191c1e] dark:text-white leading-tight mb-4">
          {lang === 'en' ? (
            <>
              Discover Every Scheme Your Family Is <span className="text-[#00685f] dark:text-teal-400 italic">Entitled</span> To Receive
            </>
          ) : (
            <>
              നിങ്ങളുടെ കുടുംബത്തിന് അർഹമായ <span className="text-[#00685f] dark:text-teal-400 italic">എല്ലാ സർക്കാർ ആനുകൂല്യങ്ങളും</span> കണ്ടെത്താം
            </>
          )}
        </h1>

        {/* Subtitle */}
        <p className="animate-fade-in-up stagger-2 text-base sm:text-lg text-[#505f76] dark:text-slate-300 max-w-3xl mx-auto mb-10 font-normal leading-relaxed">
          {lang === 'en'
            ? 'Describe your life situation in simple language. JanMitra AI analyzes thousands of official documents to deliver a personalized Family Benefit Report in seconds.'
            : 'നിങ്ങളുടെ വിവരങ്ങളും വരുമാനവും ആവശ്യങ്ങളും ലളിതമായ ഭാഷയിൽ എഴുതുക. ജനമിത്ര AI അർഹത അപഗ്രഥിച്ച് വിവരങ്ങൾ തരും.'}
        </p>

        {/* AI Search Container Box */}
        <form 
          onSubmit={handleSubmit} 
          className="animate-fade-in-up stagger-3 bg-white dark:bg-slate-900 shadow-xl rounded-3xl p-6 sm:p-8 border border-[#e0e3e5] dark:border-slate-800 text-left relative transition-all duration-300 focus-within:border-[#00685f] max-w-4xl mx-auto"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-[#00685f] dark:text-teal-400" />
              <label htmlFor="user-story-input" className="text-xs font-extrabold uppercase tracking-wider text-[#00685f] dark:text-teal-300">
                {lang === 'en' ? 'DESCRIBE YOUR SITUATION' : 'നിങ്ങളുടെ സാഹചര്യം വിശദീകരിക്കുക'}
              </label>
            </div>
            <span className="text-[11px] text-[#505f76] dark:text-slate-400 flex items-center gap-1 font-medium">
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              {lang === 'en' ? 'No complex forms required' : 'ഫോമുകൾ പൂരിപ്പിക്കേണ്ടതില്ല'}
            </span>
          </div>

          <textarea
            id="user-story-input"
            rows={4}
            value={inputStory}
            onChange={(e) => setInputStory(e.target.value)}
            placeholder="e.g. I am a widowed woman from Kochi with two school-going children. My annual household income is ₹2.5 lakh and I am looking for education and housing support..."
            className="w-full bg-[#f2f4f6] dark:bg-slate-950 text-[#191c1e] dark:text-white placeholder:text-slate-400 text-sm sm:text-base p-4 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-[#00685f]/30 focus:border-[#00685f] resize-y leading-relaxed transition-all font-medium"
            required
          />

          {/* Preset Example Story Chips */}
          <div className="mt-4 pt-3 border-t border-[#e0e3e5] dark:border-slate-800">
            <p className="text-xs font-semibold text-[#505f76] dark:text-slate-400 mb-2">
              {lang === 'en' ? 'Try sample situations:' : 'മാതൃകാ ഉദാഹരണങ്ങൾ:'}
            </p>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_PRESET_STORIES.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleChipClick(preset.prompt)}
                  className={`text-xs px-3 py-1.5 rounded-xl border transition-all text-left flex items-center space-x-1.5 cursor-pointer ${
                    inputStory === preset.prompt
                      ? 'bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border-[#00685f]/40 font-bold shadow-2xs'
                      : 'bg-[#eceef0] dark:bg-slate-800 hover:bg-[#e0e3e5] text-slate-700 dark:text-slate-300 border-[#e0e3e5] dark:border-slate-700 font-medium'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00685f]" />
                  <span>{preset.label}</span>
                  <span className="text-[10px] opacity-70">({preset.income})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Primary CTA */}
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-[#505f76] dark:text-slate-400 flex items-center space-x-1.5 font-medium">
              <Lock className="w-3.5 h-3.5 text-[#00685f] dark:text-teal-400" />
              <span>{lang === 'en' ? 'Private & Encrypted • No registration needed' : 'നിങ്ങളുടെ വിവരങ്ങൾ സുരക്ഷിതമാണ്'}</span>
            </div>

            <button
              id="find-benefits-btn"
              type="submit"
              disabled={isAnalyzing}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-[#00685f] hover:bg-[#005049] text-white font-black text-sm sm:text-base shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 group cursor-pointer"
            >
              <span>{lang === 'en' ? 'GENERATE MY REPORT' : 'ആനുകൂല്യങ്ങൾ കണ്ടെത്തുക'}</span>
              <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </form>

        {/* Trust Badges */}
        <div className="animate-fade-in-up stagger-3 flex flex-wrap justify-center gap-6 sm:gap-10 mt-8 text-xs font-bold text-[#505f76] dark:text-slate-400">
          <div className="flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-[#00685f] dark:text-teal-400" />
            <span>Grounded in Official Gazettes</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Lock className="w-4 h-4 text-[#00685f] dark:text-teal-400" />
            <span>Private & Encrypted</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Globe className="w-4 h-4 text-[#00685f] dark:text-teal-400" />
            <span>Available in മലയാളം</span>
          </div>
        </div>

        {/* Section 2: THE JANMITRA ADVANTAGE (Grid with visual showcase) */}
        <div className="mt-20 pt-12 border-t border-[#e0e3e5] dark:border-slate-800 text-left">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-[#00685f] dark:text-teal-400 block mb-1">
                  THE JANMITRA ADVANTAGE
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
                  Bridging the gap between policy and people.
                </h2>
                <p className="text-xs sm:text-sm text-[#505f76] dark:text-slate-300 font-normal leading-relaxed mt-3">
                  Millions in welfare funds go unclaimed every year due to complex eligibility rules. Our AI simplifies the discovery process by mapping your unique profile to current government schemes instantly.
                </p>
              </div>

              {/* Feature Bullet Points */}
              <div className="space-y-4 pt-2">
                <div className="flex items-start space-x-3.5 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 shadow-2xs">
                  <div className="w-8 h-8 rounded-xl bg-[#00685f]/10 text-[#00685f] flex items-center justify-center font-bold shrink-0">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                      Eligibility Scoring
                    </h4>
                    <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium mt-0.5">
                      See a % match score based on your specific financial and social criteria.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3.5 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 shadow-2xs">
                  <div className="w-8 h-8 rounded-xl bg-[#00685f]/10 text-[#00685f] flex items-center justify-center font-bold shrink-0">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                      Missing Doc Alerts
                    </h4>
                    <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium mt-0.5">
                      Instantly know which documents you are missing for a successful application.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Graphic Showcase Card */}
            <div className="lg:col-span-6 relative">
              <div className="bg-gradient-to-tr from-[#00685f] to-[#004d46] p-6 sm:p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
                
                <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />

                {/* Simulated Screen Dashboard Header */}
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 mb-6 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-rose-400" />
                    <div className="w-3 h-3 rounded-full bg-amber-400" />
                    <div className="w-3 h-3 rounded-full bg-emerald-400" />
                    <span className="text-[10px] font-mono font-bold text-teal-100 ml-2">SCHEME INSIGHTS</span>
                  </div>
                  <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">Real-time data synchronization</span>
                </div>

                {/* Big Animated Counter Card */}
                <div className="bg-white/15 backdrop-blur-md p-6 rounded-2xl border border-white/20 text-center space-y-1 mb-6">
                  <span className="text-4xl sm:text-5xl font-black tracking-tight text-white block">
                    {citizensCount.toLocaleString('en-IN')}+
                  </span>
                  <span className="text-xs font-extrabold uppercase tracking-widest text-teal-100">
                    CITIZENS HELPED
                  </span>
                </div>

                {/* Report Accuracy Badge */}
                <div className="bg-white text-slate-900 p-3 rounded-xl flex items-center justify-between font-bold text-xs shadow-md">
                  <span className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-[#00685f]" />
                    <span>AI Gazette Mapping Engine</span>
                  </span>
                  <span className="text-[#00685f] font-extrabold">Report Accuracy: 98.4%</span>
                </div>

              </div>
            </div>

          </div>

        </div>

        {/* Section 3: Widely Searched Schemes Grid */}
        <div className="mt-16 pt-12 border-t border-[#e0e3e5] dark:border-slate-800 text-left">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-[#00685f] dark:text-teal-400 block mb-1">
                Widely Searched Schemes
              </span>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                Start with these common benefit packages for Kerala residents.
              </h3>
            </div>

            {onViewAllSchemes && (
              <button
                onClick={onViewAllSchemes}
                className="text-xs font-extrabold text-[#00685f] dark:text-teal-400 hover:underline flex items-center gap-1 cursor-pointer shrink-0"
              >
                <span>VIEW ALL SCHEMES</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* 3 Featured Scheme Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Card 1: Suvarna Jubilee Scholarship */}
            <div 
              onClick={() => onSelectScheme?.('sch-suvarna-jubilee')}
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 shadow-xs hover-lift transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-0.5 rounded-md bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 text-[10px] font-black uppercase tracking-wider">
                    EDUCATION
                  </span>
                  <GraduationCap className="w-4 h-4 text-[#00685f]" />
                </div>

                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mb-2 line-clamp-1">
                  Suvarna Jubilee Merit Scholarship
                </h4>
                <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium leading-relaxed mb-4 line-clamp-3">
                  Financial assistance to needy students pursuing first year under-graduate or post-graduate courses in Government/Aided colleges in Kerala.
                </p>
              </div>

              <div className="pt-3 border-t border-[#e0e3e5] dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#505f76] block uppercase">GRANT AMOUNT</span>
                  <span className="text-sm font-black text-[#00685f] dark:text-teal-300">₹10,000 / Year</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#f2f4f6] dark:bg-slate-800 flex items-center justify-center text-[#00685f]">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Card 2: LIFE Mission Housing */}
            <div 
              onClick={() => onSelectScheme?.('sch-pmay-life')}
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 shadow-xs hover-lift transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-0.5 rounded-md bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 text-[10px] font-black uppercase tracking-wider">
                    HOUSING
                  </span>
                  <Home className="w-4 h-4 text-[#00685f]" />
                </div>

                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mb-2 line-clamp-1">
                  LIFE Mission Housing Program
                </h4>
                <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium leading-relaxed mb-4 line-clamp-3">
                  Comprehensive housing security for all landless and homeless people in the state, providing durable concrete houses and repair grants.
                </p>
              </div>

              <div className="pt-3 border-t border-[#e0e3e5] dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#505f76] block uppercase">GRANT AMOUNT</span>
                  <span className="text-sm font-black text-[#00685f] dark:text-teal-300">Full Construction Cost</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#f2f4f6] dark:bg-slate-800 flex items-center justify-center text-[#00685f]">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Card 3: PM Kisan Samman Nidhi */}
            <div 
              onClick={() => onSelectScheme?.('sch-pm-kisan')}
              className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 shadow-xs hover-lift transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-0.5 rounded-md bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 text-[10px] font-black uppercase tracking-wider">
                    AGRICULTURE
                  </span>
                  <Sprout className="w-4 h-4 text-[#00685f]" />
                </div>

                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mb-2 line-clamp-1">
                  PM Kisan Samman Nidhi
                </h4>
                <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium leading-relaxed mb-4 line-clamp-3">
                  A central scheme providing income support of ₹6,000 per year in three installments to all landholding farmer families across Kerala.
                </p>
              </div>

              <div className="pt-3 border-t border-[#e0e3e5] dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#505f76] block uppercase">GRANT AMOUNT</span>
                  <span className="text-sm font-black text-[#00685f] dark:text-teal-300">₹6,000 / Year</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#f2f4f6] dark:bg-slate-800 flex items-center justify-center text-[#00685f]">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Section 4: Stay Updated Newsletter Banner Bottom */}
        <div className="mt-16 bg-[#191c1e] text-white p-8 sm:p-10 rounded-3xl relative overflow-hidden text-left shadow-xl">
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-[#00685f]/30 rounded-full blur-2xl pointer-events-none" />

          <div className="max-w-2xl relative z-10 space-y-3">
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-teal-400" />
              <span className="text-xs font-extrabold uppercase tracking-widest text-teal-300">Stay updated on new benefits.</span>
            </div>
            
            <p className="text-xs text-slate-300 font-medium">
              We scan for new government orders daily. Join 50,000+ citizens who get alert updates.
            </p>

            {subscribed ? (
              <div className="bg-[#00685f]/20 border border-[#00685f]/40 p-3 rounded-2xl text-teal-300 text-xs font-bold flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-teal-300" />
                <span>Thank you! You are subscribed to Kerala Gazette welfare updates.</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-2 pt-2">
                <input
                  type="text"
                  value={newsletterInput}
                  onChange={(e) => setNewsletterInput(e.target.value)}
                  placeholder="Enter your mobile or email address"
                  className="bg-slate-900 border border-slate-700 text-white placeholder:text-slate-500 text-xs px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/50 flex-1"
                  required
                />
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#00685f] hover:bg-[#005049] text-white font-extrabold text-xs transition-all cursor-pointer shrink-0"
                >
                  SUBSCRIBE NOW
                </button>
              </form>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
