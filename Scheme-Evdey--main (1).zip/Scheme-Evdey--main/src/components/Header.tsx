import React from 'react';
import { ShieldCheck, FileText, RotateCcw, Sparkles, User, LayoutDashboard, BookmarkCheck } from 'lucide-react';

interface HeaderProps {
  onStartOver?: () => void;
  lang: 'en' | 'ml';
  setLang: (lang: 'en' | 'ml') => void;
  hasReport: boolean;
  onOpenExport?: () => void;
  activeTab?: 'dashboard' | 'my_schemes' | 'profile';
  setActiveTab?: (tab: 'dashboard' | 'my_schemes' | 'profile') => void;
  savedSchemesCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onStartOver,
  lang,
  setLang,
  hasReport,
  onOpenExport,
  activeTab = 'dashboard',
  setActiveTab,
  savedSchemesCount = 0
}) => {
  return (
    <header id="main-header" className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-[#e0e3e5] dark:border-slate-800 text-slate-900 dark:text-white transition-all shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Logo & Brand */}
        <div 
          className="flex items-center space-x-3 cursor-pointer group"
          onClick={() => setActiveTab ? setActiveTab('dashboard') : onStartOver?.()}
        >
          <div className="w-9 h-9 rounded-xl bg-[#00685f] text-white flex items-center justify-center font-bold shadow-md shadow-[#00685f]/20 group-hover:scale-105 transition-transform">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight text-[#191c1e] dark:text-white">
                JanMitra AI
              </span>
            </div>
          </div>
        </div>

        {/* Center Nav Links (Exact match to screenshot: Dashboard | My Schemes | Profile) */}
        <nav className="hidden md:flex items-center space-x-1 bg-[#f2f4f6] dark:bg-slate-950 p-1 rounded-full border border-[#e0e3e5] dark:border-slate-800">
          <button
            onClick={() => setActiveTab?.('dashboard')}
            className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-[#00685f] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab?.('my_schemes')}
            className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'my_schemes'
                ? 'bg-[#00685f] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <BookmarkCheck className="w-3.5 h-3.5" />
            <span>My Schemes</span>
            {savedSchemesCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-white/20 text-white font-extrabold">
                {savedSchemesCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab?.('profile')}
            className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-[#00685f] text-white shadow-xs'
                : 'text-slate-700 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile</span>
          </button>
        </nav>

        {/* Right Action Bar */}
        <div className="flex items-center space-x-2.5">
          
          {/* Language Toggle */}
          <div className="flex bg-[#eceef0] dark:bg-slate-800 p-1 rounded-full border border-[#e0e3e5] dark:border-slate-700">
            <button
              onClick={() => setLang('en')}
              className={`px-2.5 py-0.5 text-xs font-bold rounded-full transition-all cursor-pointer ${
                lang === 'en'
                  ? 'bg-white dark:bg-slate-700 text-[#00685f] dark:text-teal-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLang('ml')}
              className={`px-2.5 py-0.5 text-xs font-bold rounded-full transition-all cursor-pointer ${
                lang === 'ml'
                  ? 'bg-white dark:bg-slate-700 text-[#00685f] dark:text-teal-300 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              മല
            </button>
          </div>

          {/* Download/Export Button if Report Active */}
          {hasReport && onOpenExport && (
            <button
              id="header-export-btn"
              onClick={onOpenExport}
              className="hidden sm:flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-[#00685f] hover:bg-[#005049] text-white shadow-xs transition-all cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{lang === 'en' ? 'Report' : 'റിപ്പോർട്ട്'}</span>
            </button>
          )}

          {/* Start Over Button */}
          {onStartOver && (
            <button
              id="header-start-over-btn"
              onClick={onStartOver}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-bold text-slate-700 dark:text-slate-200 bg-[#eceef0] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 border border-[#bcc9c6] dark:border-slate-700 transition-colors cursor-pointer"
              title="Start Over"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#00685f] dark:text-teal-400" />
              <span className="hidden sm:inline">{lang === 'en' ? 'Start Over' : 'വീണ്ടും'}</span>
            </button>
          )}

          {/* User Profile Avatar Icon Button */}
          <button
            onClick={() => setActiveTab?.('profile')}
            className="w-8 h-8 rounded-full bg-[#f2f4f6] dark:bg-slate-800 border border-[#e0e3e5] dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 hover:bg-[#00685f]/10 transition-colors cursor-pointer"
            title="User Profile"
          >
            <User className="w-4 h-4" />
          </button>

        </div>

      </div>

      {/* Mobile Sub-Nav Bar */}
      <div className="md:hidden flex items-center justify-around bg-[#f7f9fb] dark:bg-slate-950 border-t border-[#e0e3e5] dark:border-slate-800 px-4 py-2">
        <button
          onClick={() => setActiveTab?.('dashboard')}
          className={`flex items-center space-x-1 text-xs font-bold px-3 py-1 rounded-full ${
            activeTab === 'dashboard' ? 'bg-[#00685f] text-white' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab?.('my_schemes')}
          className={`flex items-center space-x-1 text-xs font-bold px-3 py-1 rounded-full ${
            activeTab === 'my_schemes' ? 'bg-[#00685f] text-white' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <BookmarkCheck className="w-3.5 h-3.5" />
          <span>My Schemes</span>
        </button>

        <button
          onClick={() => setActiveTab?.('profile')}
          className={`flex items-center space-x-1 text-xs font-bold px-3 py-1 rounded-full ${
            activeTab === 'profile' ? 'bg-[#00685f] text-white' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Profile</span>
        </button>
      </div>

    </header>
  );
};
