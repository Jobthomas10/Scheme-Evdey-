import React from 'react';
import { Scheme } from '../types';
import { BookmarkCheck, ExternalLink, IndianRupee, Trash2, ArrowRight } from 'lucide-react';

interface MySchemesTabProps {
  savedSchemes: Scheme[];
  lang: 'en' | 'ml';
  onSelectScheme: (scheme: Scheme) => void;
  onRemoveBookmark: (schemeId: string) => void;
  onNavigateHome: () => void;
}

export const MySchemesTab: React.FC<MySchemesTabProps> = ({
  savedSchemes,
  lang,
  onSelectScheme,
  onRemoveBookmark,
  onNavigateHome
}) => {
  const totalValue = savedSchemes.reduce((acc, curr) => acc + curr.estimatedAnnualValue, 0);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 mb-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#00685f]/10 text-[#00685f] text-xs font-bold mb-2">
            <BookmarkCheck className="w-3.5 h-3.5" />
            <span>Saved Benefit Packages</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            My Schemes & Application Trackers
          </h2>
          <p className="text-xs text-[#505f76] dark:text-slate-400 mt-1 font-medium">
            Keep track of the schemes you have bookmarked, review requirements, and complete filing.
          </p>
        </div>

        {/* Total Value Counter */}
        <div className="bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 p-5 rounded-2xl text-left md:text-right shrink-0 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#505f76] block">
            Combined Saved Value
          </span>
          <span className="text-2xl font-black text-[#00685f] dark:text-teal-300">
            ₹{totalValue.toLocaleString('en-IN')}/yr
          </span>
        </div>
      </div>

      {savedSchemes.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-[#00685f]/10 text-[#00685f] flex items-center justify-center mx-auto">
            <BookmarkCheck className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white">
            No saved schemes yet
          </h3>
          <p className="text-xs text-[#505f76] dark:text-slate-400 max-w-md mx-auto font-medium">
            Browse through your Benefit Assessment or Widely Searched Schemes and click the bookmark button to save schemes here for quick tracking.
          </p>
          <button
            onClick={onNavigateHome}
            className="px-6 py-3 rounded-2xl bg-[#00685f] text-white font-extrabold text-xs shadow-xs hover:bg-[#005049] transition-all cursor-pointer"
          >
            Explore Schemes Now
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {savedSchemes.map((scheme) => (
            <div
              key={scheme.id}
              className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-6 shadow-xs hover-lift transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center space-x-2 text-xs text-[#505f76]">
                  <span className="font-bold text-[#00685f]">{scheme.department}</span>
                  <span>•</span>
                  <span>{scheme.stateOrCentral}</span>
                </div>

                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  {scheme.title}
                </h3>
                {scheme.malayalamTitle && (
                  <p className="text-xs font-bold text-[#00685f]">
                    {scheme.malayalamTitle}
                  </p>
                )}

                <p className="text-xs text-[#505f76] dark:text-slate-400 line-clamp-2 font-medium pt-1">
                  {scheme.shortSummary}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center gap-3 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-[#e0e3e5] dark:border-slate-800">
                <div className="text-left sm:text-right pr-2">
                  <span className="text-[10px] font-bold text-[#505f76] uppercase block">Value</span>
                  <span className="text-base font-black text-[#00685f]">
                    ₹{scheme.estimatedAnnualValue.toLocaleString('en-IN')}/yr
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onSelectScheme(scheme)}
                    className="px-4 py-2 rounded-xl bg-[#00685f] text-white font-bold text-xs shadow-xs hover:bg-[#005049] transition-all flex items-center space-x-1 cursor-pointer"
                  >
                    <span>View Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  {scheme.officialPortalUrl && (
                    <a
                      href={scheme.officialPortalUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded-xl bg-[#f2f4f6] dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-[#e0e3e5] dark:border-slate-700 hover:text-[#00685f]"
                      title="Apply on Official Portal"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}

                  <button
                    onClick={() => onRemoveBookmark(scheme.id)}
                    className="p-2 rounded-xl bg-[#ba1a1a]/10 text-[#ba1a1a] hover:bg-[#ba1a1a]/20 transition-colors cursor-pointer"
                    title="Remove from saved"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
