import React from 'react';
import { Scheme } from '../types';
import { X, ExternalLink, CheckCircle2, AlertCircle, Building2, Sparkles, FileText, Download, Lock, ChevronRight, Upload } from 'lucide-react';

interface SchemeDetailsModalProps {
  scheme: Scheme | null;
  onClose: () => void;
  lang: 'en' | 'ml';
  onUploadDoc?: (docName: string) => void;
}

export const SchemeDetailsModal: React.FC<SchemeDetailsModalProps> = ({
  scheme,
  onClose,
  lang,
  onUploadDoc
}) => {
  if (!scheme) return null;

  const formattedValue = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(scheme.estimatedAnnualValue);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#191c1e]/70 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="max-w-4xl w-full bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl shadow-2xl text-slate-900 dark:text-white relative overflow-hidden my-8 max-h-[90vh] flex flex-col">
        
        {/* Modal Top Navigation Header */}
        <div className="p-6 pb-4 border-b border-[#e0e3e5] dark:border-slate-800 flex items-center justify-between bg-[#f8faf9] dark:bg-slate-950/60 shrink-0">
          <div className="flex items-center space-x-2 text-xs font-bold text-[#00685f] dark:text-teal-400">
            <Building2 className="w-4 h-4" />
            <span>{scheme.department}</span>
            <span>•</span>
            <span className="text-[#505f76] dark:text-slate-400">{scheme.stateOrCentral}</span>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-[#eceef0] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 text-[#505f76] dark:text-slate-300 transition-colors cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-8 flex-1">
          
          {/* Main Title Header & Top Metric Badge */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 border-b border-[#e0e3e5] dark:border-slate-800 pb-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                <span className={`px-3 py-1 rounded-full text-xs font-extrabold border ${
                  scheme.status === 'ready_today' 
                    ? 'bg-[#00685f]/10 text-[#00685f] border-[#00685f]/20'
                    : 'bg-[#ba1a1a]/10 text-[#ba1a1a] border-[#ba1a1a]/20'
                }`}>
                  {scheme.status === 'ready_today' 
                    ? (lang === 'en' ? '✓ Ready Today' : 'ഉടൻ അപേക്ഷിക്കാം') 
                    : (lang === 'en' ? '⚠️ Missing 1 Document' : '1 രേഖ വേണം')}
                </span>
                
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#eceef0] dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-[#e0e3e5] dark:border-slate-700">
                  {scheme.category.toUpperCase()}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
                {scheme.title}
              </h2>
              {scheme.malayalamTitle && (
                <p className="text-base font-bold text-[#00685f] dark:text-teal-400">
                  {scheme.malayalamTitle}
                </p>
              )}

              <p className="text-sm text-[#505f76] dark:text-slate-300 font-normal leading-relaxed pt-1">
                {scheme.shortSummary}
              </p>
            </div>

            {/* Right Metric Showcase Card */}
            <div className="bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-5 shrink-0 text-left md:text-right space-y-3 min-w-[220px] shadow-2xs">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#505f76] dark:text-slate-400 block">
                  Est. Annual Value
                </span>
                <span className="text-2xl font-black text-[#00685f] dark:text-teal-300 block">
                  {formattedValue}
                </span>
              </div>

              <div className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border border-[#00685f]/20">
                <Sparkles className="w-3.5 h-3.5 text-[#00685f]" />
                <span>{scheme.confidenceScore}% Confidence Score</span>
              </div>

              {scheme.officialPortalUrl && (
                <a
                  href={scheme.officialPortalUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full mt-2 px-4 py-2 rounded-xl bg-[#00685f] hover:bg-[#005049] text-white font-extrabold text-xs transition-all flex items-center justify-center space-x-1.5 shadow-xs"
                >
                  <span>Visit Official Portal</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>

          {/* 2-Column Split: Why Eligible vs Pending Requirements */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Why you are eligible Box */}
            <div className="bg-[#f7f9fb] dark:bg-slate-950 p-6 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 space-y-3">
              <div className="flex items-center space-x-2 text-[#00685f] dark:text-teal-400">
                <CheckCircle2 className="w-5 h-5 text-[#00685f]" />
                <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-white">
                  Why you are eligible
                </h3>
              </div>

              <ul className="space-y-3 pt-2">
                {scheme.whyEligible.map((reason, idx) => (
                  <li key={idx} className="flex items-start space-x-3 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium">
                    <span className="w-4 h-4 rounded-full bg-[#00685f]/15 text-[#00685f] flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">✓</span>
                    <span className="leading-relaxed">{reason}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Pending Requirements Box */}
            <div className="bg-[#ba1a1a]/5 p-6 rounded-2xl border border-[#ba1a1a]/20 space-y-3">
              <div className="flex items-center space-x-2 text-[#ba1a1a] dark:text-rose-400">
                <AlertCircle className="w-5 h-5 text-[#ba1a1a]" />
                <h3 className="text-base font-black tracking-tight">
                  Pending Requirements
                </h3>
              </div>

              <div className="pt-2 space-y-3">
                <div className="text-xs text-[#ba1a1a] dark:text-rose-300 font-medium space-y-1">
                  <span className="font-extrabold text-[11px] uppercase tracking-wider block">Required Action:</span>
                  {scheme.whyNotOrPending && scheme.whyNotOrPending.length > 0 ? (
                    scheme.whyNotOrPending.map((item, idx) => (
                      <p key={idx} className="leading-relaxed">• {item}</p>
                    ))
                  ) : (
                    <p className="leading-relaxed">• Income Certificate and Institution Verification Pending.</p>
                  )}
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onUploadDoc && onUploadDoc(scheme.requiredDocuments[0] || 'Income Certificate')}
                    className="w-full py-2.5 px-4 rounded-xl bg-white dark:bg-slate-900 border border-[#ba1a1a]/30 hover:border-[#ba1a1a] text-[#ba1a1a] dark:text-rose-300 font-bold text-xs transition-all flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Digital Income Certificate</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* Process Flow Section: Application Roadmap & Dependencies */}
          <div className="pt-4 border-t border-[#e0e3e5] dark:border-slate-800">
            
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#00685f] dark:text-teal-400 block">
                  PROCESS FLOW
                </span>
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  Application Roadmap & Dependencies
                </h3>
              </div>

              <div className="px-3.5 py-1.5 rounded-full bg-[#00685f]/10 text-[#00685f] border border-[#00685f]/20 text-xs font-extrabold hidden sm:flex items-center space-x-1">
                <span>3 Milestone Steps</span>
              </div>
            </div>

            {/* Vertical Flow Steps */}
            <div className="relative pl-8 space-y-6 before:absolute before:left-3.5 before:top-4 before:bottom-4 before:w-0.5 before:bg-[#00685f]/30">
              
              {/* Step 1: Online Registration */}
              <div className="relative bg-[#f7f9fb] dark:bg-slate-950 p-5 rounded-2xl border border-[#e0e3e5] dark:border-slate-800">
                <div className="absolute -left-8 top-5 w-7 h-7 rounded-full bg-[#00685f] text-white flex items-center justify-center text-xs font-bold shadow-xs">
                  <CheckCircle2 className="w-4 h-4 text-white" />
                </div>

                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-base font-black text-slate-900 dark:text-white">
                    1. Online Registration
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-[#00685f]/10 text-[#00685f] border border-[#00685f]/20">
                    Completed
                  </span>
                </div>

                <p className="text-xs text-[#505f76] dark:text-slate-300 font-medium">
                  Fill the basic details on the DCE portal and select "Suvarna Jubilee Merit Scholarship" from the scheme list.
                </p>
              </div>

              {/* Step 2: Verification & Hard Copy */}
              <div className="relative bg-white dark:bg-slate-900 p-5 rounded-2xl border-2 border-[#00685f] shadow-xs">
                <div className="absolute -left-8 top-5 w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs font-bold shadow-xs">
                  2
                </div>

                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-base font-black text-slate-900 dark:text-white">
                    2. Verification & Hard Copy
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/10 text-amber-700 border border-amber-500/20">
                    Action Required
                  </span>
                </div>

                <p className="text-xs text-[#505f76] dark:text-slate-300 font-medium mb-3">
                  Print the application form and submit it with self-attested documents to the college office.
                </p>

                <button
                  onClick={() => alert('Application form template downloaded successfully.')}
                  className="px-4 py-2 rounded-xl bg-[#00685f] hover:bg-[#005049] text-white font-bold text-xs transition-all inline-flex items-center space-x-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Form</span>
                </button>
              </div>

              {/* Step 3: Fund Disbursement */}
              <div className="relative bg-[#f7f9fb] dark:bg-slate-950 p-5 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 opacity-60">
                <div className="absolute -left-8 top-5 w-7 h-7 rounded-full bg-slate-300 dark:bg-slate-800 text-slate-600 flex items-center justify-center text-xs font-bold">
                  <Lock className="w-3.5 h-3.5" />
                </div>

                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-base font-black text-slate-900 dark:text-white">
                    3. Fund Disbursement
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 dark:bg-slate-800 text-slate-600">
                    Locked
                  </span>
                </div>

                <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium">
                  Direct Benefit Transfer (DBT) to the linked bank account after final approval from the directorate.
                </p>
              </div>

            </div>

          </div>

          {/* Official Gazette Citation Box */}
          <div className="bg-[#f2f4f6] dark:bg-slate-950 p-4 rounded-2xl border border-[#e0e3e5] dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-2">
            <div className="flex items-center justify-between font-bold text-[#00685f] dark:text-teal-400">
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#00685f]" />
                <span>{scheme.citation.docName}</span>
              </span>
              <span className="font-mono bg-[#00685f]/10 px-2.5 py-0.5 rounded">{scheme.citation.clauseNumber}</span>
            </div>
            <p className="italic bg-white dark:bg-slate-900 p-3 rounded-xl border border-[#e0e3e5] dark:border-slate-800">
              "{scheme.citation.excerpt}"
            </p>
          </div>

        </div>

        {/* Modal Footer Bar */}
        <div className="p-4 sm:px-8 border-t border-[#e0e3e5] dark:border-slate-800 bg-[#f8faf9] dark:bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <span className="text-xs text-[#505f76] font-semibold">
            How to Apply: <strong className="text-slate-900 dark:text-white">{scheme.howToApply}</strong>
          </span>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-[#eceef0] dark:bg-slate-800 hover:bg-[#e0e3e5] dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs transition-all cursor-pointer"
            >
              Close
            </button>

            {scheme.officialPortalUrl && (
              <a
                href={scheme.officialPortalUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-[#00685f] hover:bg-[#005049] text-white font-extrabold text-xs transition-all shadow-xs text-center flex items-center justify-center space-x-1.5"
              >
                <span>Apply Now</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
