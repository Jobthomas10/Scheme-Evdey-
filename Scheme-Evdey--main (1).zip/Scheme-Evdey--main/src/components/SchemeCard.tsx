import React, { useState } from 'react';
import { Scheme } from '../types';
import { CheckCircle2, ChevronDown, ChevronUp, ExternalLink, FileText, AlertCircle, BookmarkCheck, Building2, Sparkles, ShieldAlert, ArrowRight } from 'lucide-react';

interface SchemeCardProps {
  scheme: Scheme;
  lang: 'en' | 'ml';
  onBookmarked?: (schemeId: string) => void;
  isBookmarked?: boolean;
}

export const SchemeCard: React.FC<SchemeCardProps> = ({
  scheme,
  lang,
  onBookmarked,
  isBookmarked
}) => {
  const [showCitation, setShowCitation] = useState<boolean>(false);
  const [showDetails, setShowDetails] = useState<boolean>(true);

  // Currency format
  const formattedValue = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(scheme.estimatedAnnualValue);

  // Status badge styling
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ready_today':
        return {
          label: lang === 'en' ? 'Ready Today' : 'അടിയന്തര അപേക്ഷ',
          bg: 'bg-[#00685f]/10 text-[#00685f] border-[#00685f]/20'
        };
      case 'missing_docs':
        return {
          label: lang === 'en' ? 'Missing 1 Document' : '1 രേഖ ഹാജരാക്കണം',
          bg: 'bg-[#ba1a1a]/10 text-[#ba1a1a] border-[#ba1a1a]/20'
        };
      default:
        return {
          label: lang === 'en' ? 'Verification Needed' : 'പരിശോധന വേണം',
          bg: 'bg-amber-500/10 text-amber-700 border-amber-500/20'
        };
    }
  };

  const statusInfo = getStatusBadge(scheme.status);

  return (
    <div 
      id={`scheme-card-${scheme.id}`}
      className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-6 shadow-xs hover-lift transition-all duration-300 relative mb-5"
    >
      
      {/* Top Bar: Dept + State/Central Tag + Confidence Pill */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center space-x-2 text-xs text-[#505f76] dark:text-slate-400 font-medium">
          <Building2 className="w-3.5 h-3.5 text-[#00685f] dark:text-teal-400" />
          <span className="font-semibold truncate max-w-[200px] sm:max-w-xs text-slate-800 dark:text-slate-200">{scheme.department}</span>
          <span>•</span>
          <span className="font-bold px-2 py-0.5 rounded bg-[#eceef0] dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-[#e0e3e5] dark:border-slate-700">
            {scheme.stateOrCentral}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Confidence percentage badge */}
          <div className="flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border border-[#00685f]/20">
            <Sparkles className="w-3 h-3 text-[#00685f]" />
            <span>{scheme.confidenceScore}% Match Confidence</span>
          </div>

          {/* Bookmark Button */}
          {onBookmarked && (
            <button
              onClick={() => onBookmarked(scheme.id)}
              className={`p-1.5 rounded-lg border text-xs transition-colors cursor-pointer ${
                isBookmarked 
                  ? 'bg-[#00685f]/15 text-[#00685f] border-[#00685f]/40' 
                  : 'bg-[#f2f4f6] dark:bg-slate-800 text-slate-400 border-[#e0e3e5] dark:border-slate-700 hover:text-slate-700'
              }`}
              title="Save Scheme"
            >
              <BookmarkCheck className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Scheme Title & Annual Benefit Value */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-4">
        <div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {scheme.title}
          </h3>
          {scheme.malayalamTitle && (
            <p className="text-xs font-bold text-[#00685f] dark:text-teal-400 mt-0.5">
              {scheme.malayalamTitle}
            </p>
          )}
        </div>

        {/* Estimated Annual Value Box */}
        <div className="bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl px-4 py-2.5 shrink-0 text-left sm:text-right shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#505f76] dark:text-slate-400 block">
            {lang === 'en' ? 'Est. Annual Value' : 'വാർഷിക തുക'}
          </span>
          <span className="text-xl sm:text-2xl font-black text-[#00685f] dark:text-teal-300">
            {formattedValue}
          </span>
        </div>
      </div>

      {/* Status Pill + Short Summary */}
      <div className="flex items-center space-x-2 mb-4">
        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${statusInfo.bg}`}>
          {statusInfo.label}
        </span>
        <span className="text-xs text-[#505f76] dark:text-slate-300 font-medium line-clamp-2">
          {scheme.shortSummary}
        </span>
      </div>

      {/* Accordion: Why Eligible / Why Not */}
      {showDetails && (
        <div className="my-4 pt-4 border-t border-[#e0e3e5] dark:border-slate-800 space-y-3">
          
          {/* Why Eligible List */}
          <div className="bg-[#f7f9fb] dark:bg-slate-950/60 p-3.5 rounded-xl border border-[#e0e3e5] dark:border-slate-800">
            <h4 className="text-xs font-bold text-[#00685f] dark:text-teal-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00685f]" />
              <span>{lang === 'en' ? 'Why You Are Eligible' : 'അർഹതാ കാരണങ്ങൾ'}</span>
            </h4>
            <ul className="space-y-1.5 pl-1">
              {scheme.whyEligible.map((reason, idx) => (
                <li key={idx} className="text-xs text-slate-800 dark:text-slate-200 font-medium flex items-start space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00685f] mt-1.5 shrink-0" />
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Why Pending / Missing Docs */}
          {scheme.whyNotOrPending && scheme.whyNotOrPending.length > 0 && (
            <div className="bg-[#ba1a1a]/5 p-3.5 rounded-xl border border-[#ba1a1a]/20">
              <h4 className="text-xs font-bold text-[#ba1a1a] dark:text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-[#ba1a1a]" />
                <span>{lang === 'en' ? 'Pending Requirements / Missing Docs' : 'ലഭ്യമാക്കേണ്ട രേഖകൾ'}</span>
              </h4>
              <ul className="space-y-1.5 pl-1">
                {scheme.whyNotOrPending.map((pending, idx) => (
                  <li key={idx} className="text-xs text-[#ba1a1a] dark:text-rose-300 font-medium flex items-start space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a] mt-1.5 shrink-0" />
                    <span>{pending}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

        </div>
      )}

      {/* Clause Citation Box (Expandable) */}
      <div className="mt-4 pt-3 border-t border-[#e0e3e5] dark:border-slate-800">
        <button
          onClick={() => setShowCitation(!showCitation)}
          className="w-full flex items-center justify-between text-xs font-bold text-[#505f76] dark:text-slate-400 hover:text-[#00685f] transition-colors py-1 cursor-pointer"
        >
          <span className="flex items-center space-x-1.5">
            <FileText className="w-3.5 h-3.5 text-[#00685f]" />
            <span>{lang === 'en' ? 'View Official Scheme Citation & Clause' : 'ഔദ്യോഗിക ഉത്തരവ് വിവരങ്ങൾ'}</span>
          </span>
          {showCitation ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showCitation && (
          <div className="mt-2.5 p-4 rounded-xl bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-2 animate-fade-in-up">
            <div className="flex items-center justify-between text-[11px] font-bold text-[#00685f] dark:text-teal-400 border-b border-[#e0e3e5] dark:border-slate-800 pb-1.5">
              <span>{scheme.citation.docName}</span>
              <span className="font-mono bg-[#00685f]/10 px-2 py-0.5 rounded">{scheme.citation.clauseNumber}</span>
            </div>
            <p className="italic text-slate-700 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-900 p-3 rounded-lg border border-[#e0e3e5] dark:border-slate-800 font-medium">
              "{scheme.citation.excerpt}"
            </p>
            {scheme.citation.officialUrl && (
              <a
                href={scheme.citation.officialUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center text-[11px] font-bold text-[#00685f] hover:underline pt-1"
              >
                <span>Verify on Official Kerala Gazette Portal</span>
                <ExternalLink className="w-3 h-3 ml-1" />
              </a>
            )}
          </div>
        )}
      </div>

      {/* Action Footer Bar */}
      <div className="mt-4 pt-3 border-t border-[#e0e3e5] dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <span className="text-[11px] text-[#505f76] dark:text-slate-400 font-medium">
          How to Apply: <span className="text-slate-800 dark:text-slate-200 font-semibold">{scheme.howToApply}</span>
        </span>

        {scheme.officialPortalUrl && (
          <a
            href={scheme.officialPortalUrl}
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2.5 rounded-xl bg-[#00685f] hover:bg-[#005049] text-white font-bold text-xs transition-all shadow-xs flex items-center justify-center space-x-1.5 shrink-0"
          >
            <span>{lang === 'en' ? 'Apply on Official Portal' : 'അപേക്ഷിക്കുക'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}
      </div>

    </div>
  );
};

