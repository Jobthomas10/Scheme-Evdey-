import React from 'react';
import { ClarifyingQuestion } from '../types';
import { HelpCircle, Sparkles, CheckCircle2 } from 'lucide-react';

interface ClarifyingModalProps {
  question: ClarifyingQuestion;
  onAnswer: (selectedOption: { label: string; value: string; impactOnScore: string }) => void;
  onSkip: () => void;
  lang: 'en' | 'ml';
}

export const ClarifyingModal: React.FC<ClarifyingModalProps> = ({
  question,
  onAnswer,
  onSkip,
  lang
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#191c1e]/60 backdrop-blur-xs animate-fade-in">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-slate-900 dark:text-white relative overflow-hidden">
        
        {/* Top Accent Pill */}
        <div className="inline-flex items-center space-x-1.5 bg-[#00685f]/10 border border-[#00685f]/20 px-3.5 py-1 rounded-full text-xs font-extrabold text-[#00685f] dark:text-teal-400 mb-4">
          <HelpCircle className="w-3.5 h-3.5 text-[#00685f]" />
          <span>{lang === 'en' ? 'Quick Clarification' : 'വിവരങ്ങൾ സ്ഥിരീകരിക്കുക'}</span>
        </div>

        <h3 className="text-lg font-black text-slate-900 dark:text-white mb-1">
          {lang === 'en' ? question.question : question.malayalamQuestion || question.question}
        </h3>
        <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium mb-6">
          {lang === 'en'
            ? 'Answering this helps us refine your Benefit Potential Score & exact scheme eligibility.'
            : 'ഈ ചോദ്യത്തിന് ഉത്തരം നൽകുന്നത് ആനുകൂല്യ സ്കോർ കൂടുതൽ കൃത്യമാക്കാൻ സഹായിക്കും.'}
        </p>

        {/* Options */}
        <div className="space-y-2.5 mb-6">
          {question.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => onAnswer(opt)}
              className="w-full p-4 rounded-2xl bg-[#f7f9fb] dark:bg-slate-800 hover:bg-[#00685f]/5 border border-[#e0e3e5] dark:border-slate-700 hover:border-[#00685f] text-left transition-all duration-200 flex items-center justify-between group cursor-pointer"
            >
              <div>
                <span className="text-sm font-black text-slate-900 dark:text-slate-100 group-hover:text-[#00685f] dark:group-hover:text-teal-300 block">
                  {opt.label}
                </span>
                <span className="text-[11px] text-[#00685f] dark:text-teal-400 font-bold">
                  {opt.impactOnScore}
                </span>
              </div>
              <CheckCircle2 className="w-4 h-4 text-[#bcc9c6] group-hover:text-[#00685f] transition-colors" />
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-[#e0e3e5] dark:border-slate-800">
          <button
            type="button"
            onClick={onSkip}
            className="text-xs font-bold text-[#505f76] dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            {lang === 'en' ? 'Skip & Keep Estimated Score' : 'ഒഴിവാക്കുക'}
          </button>
          
          <span className="text-[10px] text-[#505f76] dark:text-slate-400 font-bold flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-500" />
            Instant Score Boost
          </span>
        </div>

      </div>
    </div>
  );
};

