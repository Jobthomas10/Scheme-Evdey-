import React, { useEffect, useState } from 'react';
import { BenefitReport } from '../types';
import { Award, IndianRupee, CheckCircle2, FileWarning, Sparkles, AlertCircle, Info, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ScoreCardProps {
  report: BenefitReport;
  lang: 'en' | 'ml';
  onRefineScoreClick?: () => void;
}

export const ScoreCard: React.FC<ScoreCardProps> = ({ report, lang, onRefineScoreClick }) => {
  const [animatedScore, setAnimatedScore] = useState<number>(0);

  useEffect(() => {
    let start = 0;
    const end = report.benefitPotentialScore;
    const duration = 1200;
    const increment = Math.ceil(end / (duration / 20));

    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setAnimatedScore(end);
        clearInterval(timer);
        if (end >= 80) {
          try {
            confetti({
              particleCount: 35,
              spread: 60,
              origin: { y: 0.3 }
            });
          } catch (e) {
            // Ignore if canvas-confetti fails
          }
        }
      } else {
        setAnimatedScore(start);
      }
    }, 20);

    return () => clearInterval(timer);
  }, [report.benefitPotentialScore]);

  // Format currency
  const formattedRupees = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(report.estimatedAnnualBenefitsRupees);

  // Score SVG gauge math
  const score = animatedScore;
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div id="hero-score-card" className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 text-slate-900 dark:text-white shadow-xl relative overflow-hidden mb-10">
      
      {/* Background ambient decor */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#00685f]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#505f76]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#e0e3e5] dark:border-slate-800 mb-6">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#00685f] dark:text-teal-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#00685f]" />
              {lang === 'en' ? 'FAMILY BENEFIT REPORT' : 'കുടുംബ ആനുകൂല്യ റിപ്പോർട്ട്'}
            </span>
            <span className="text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-mono">ID: {report.reportId}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {lang === 'en' ? 'Your Benefit Assessment' : 'നിങ്ങളുടെ അർഹത വിവരങ്ങൾ'}
          </h2>
        </div>

        {/* User Story Summary Capsule */}
        <div className="bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-3.5 text-xs text-slate-700 dark:text-slate-300 max-w-md">
          <p className="font-semibold text-slate-800 dark:text-slate-200 line-clamp-2 italic">
            "{report.userStory}"
          </p>
          <div className="flex items-center space-x-3 mt-1.5 text-[11px] font-bold text-[#00685f] dark:text-teal-400">
            <span>State: {report.extractedProfile.state}</span>
            <span>•</span>
            <span>Income: ₹{(report.extractedProfile.annualIncomeRupees || 0).toLocaleString('en-IN')}/yr</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Score Gauge + Key Stat Metric Pillars */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Col: Big Benefit Potential Score Circle (5 cols) */}
        <div className="lg:col-span-5 bg-[#f7f9fb] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center text-center relative shadow-xs">
          
          <span className="text-xs font-bold uppercase tracking-widest text-[#505f76] dark:text-slate-400 mb-3">
            {lang === 'en' ? 'Benefit Potential Score' : 'ആനുകൂല്യ സാധ്യത സ്കോർ'}
          </span>

          {/* Gauge Circle */}
          <div className="relative w-48 h-48 my-2 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
              {/* Background Ring */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className="stroke-[#eceef0] dark:stroke-slate-800"
                strokeWidth="12"
                fill="transparent"
              />
              {/* Animated Progress Ring */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                stroke="#00685f"
                strokeWidth="12"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-1000 ease-out"
              />
            </svg>

            {/* Central Score Text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <div className="flex items-baseline justify-center">
                <span className="text-5xl font-black tracking-tight text-slate-900 dark:text-white">
                  {animatedScore}
                </span>
                <span className="text-sm font-bold text-slate-400 ml-0.5">/100</span>
              </div>
              <span className="text-[10px] font-bold tracking-wider uppercase text-[#00685f] dark:text-teal-400 mt-1">
                {report.scoreLabel}
              </span>
            </div>
          </div>

          {/* Score Quality Badge */}
          <div className="mt-2 px-4 py-1.5 rounded-full text-xs font-bold bg-[#00685f]/10 text-[#00685f] dark:text-teal-300 border border-[#00685f]/20 flex items-center gap-1.5 shadow-2xs">
            <Award className="w-3.5 h-3.5" />
            <span>{report.scoreLabel}</span>
          </div>

          {/* Refine score trigger */}
          {onRefineScoreClick && (
            <button
              onClick={onRefineScoreClick}
              className="mt-3 text-xs text-[#00685f] dark:text-teal-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>{lang === 'en' ? 'Answer 1 quick question to boost score' : 'ചോദ്യത്തിന് ഉത്തരം നൽകുക'}</span>
            </button>
          )}

        </div>

        {/* Right Col: 3 Key Metric Cards (7 cols) */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          {/* Metric 1: Estimated Annual Value */}
          <div className="reveal-card delay-1 bg-white dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-xs border-l-4 border-l-[#00685f] hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#505f76] dark:text-slate-400">
                {lang === 'en' ? 'Est. Annual Value' : 'വാർഷിക തുക'}
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#00685f]/10 flex items-center justify-center text-[#00685f]">
                <IndianRupee className="w-4 h-4" />
              </div>
            </div>

            <div className="my-2">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight block">
                {formattedRupees}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 block">
                {lang === 'en' ? 'Combined pensions, health cover & grants' : 'മൊത്തം സാമ്പത്തിക ആനുകൂല്യങ്ങൾ'}
              </span>
            </div>

            <div className="pt-2.5 border-t border-[#eceef0] dark:border-slate-800 text-[11px] text-[#00685f] dark:text-teal-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>5 Verified Schemes</span>
            </div>
          </div>

          {/* Metric 2: Applications Ready Today */}
          <div className="reveal-card delay-2 bg-white dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-xs border-l-4 border-l-teal-500 hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#505f76] dark:text-slate-400">
                {lang === 'en' ? 'Ready Today' : 'അടിയന്തര അപേക്ഷകൾ'}
              </span>
              <div className="w-8 h-8 rounded-xl bg-teal-500/10 flex items-center justify-center text-teal-600">
                <Zap className="w-4 h-4" />
              </div>
            </div>

            <div className="my-2">
              <span className="text-3xl font-black text-slate-900 dark:text-white tracking-tight block">
                {report.applicationsReadyCount} <span className="text-sm font-normal text-slate-500">Schemes</span>
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 block">
                {lang === 'en' ? 'Documents ready for instant submission' : 'ഉടൻ സമർപ്പിക്കാവുന്നവ'}
              </span>
            </div>

            <div className="pt-2.5 border-t border-[#eceef0] dark:border-slate-800 text-[11px] text-teal-600 dark:text-teal-400 font-bold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Immediate Direct Benefit</span>
            </div>
          </div>

          {/* Metric 3: Missing Documents */}
          <div className="reveal-card delay-3 bg-white dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between shadow-xs border-l-4 border-l-[#ba1a1a] hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#505f76] dark:text-slate-400">
                {lang === 'en' ? 'Missing Docs' : 'ഹാജരാക്കേണ്ടവ'}
              </span>
              <div className="w-8 h-8 rounded-xl bg-[#ba1a1a]/10 flex items-center justify-center text-[#ba1a1a]">
                <FileWarning className="w-4 h-4" />
              </div>
            </div>

            <div className="my-2">
              <span className="text-3xl font-black text-[#ba1a1a] dark:text-rose-400 tracking-tight block">
                {report.missingDocsCount} <span className="text-sm font-normal text-slate-500">Certs</span>
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 block">
                {lang === 'en' ? 'Certificates required before final filing' : 'ലഭ്യമാക്കേണ്ട സർട്ടിഫിക്കറ്റുകൾ'}
              </span>
            </div>

            <div className="pt-2.5 border-t border-[#eceef0] dark:border-slate-800 text-[11px] text-[#ba1a1a] dark:text-rose-400 font-bold flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Available via Akshaya Kendra</span>
            </div>
          </div>

        </div>

      </div>

      {/* AI Reasoning Banner Bottom */}
      <div className="mt-6 pt-4 border-t border-[#e0e3e5] dark:border-slate-800 flex items-start space-x-3 bg-[#00685f]/5 p-4 rounded-2xl border border-[#00685f]/15 text-xs text-[#3d4947] dark:text-slate-300">
        <div className="p-2 bg-[#00685f] text-white rounded-xl shrink-0">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <span className="font-bold text-[#00685f] dark:text-teal-300 uppercase tracking-widest text-[11px] block mb-1">
            JanMitra AI Reasoning Summary
          </span>
          <p className="leading-relaxed text-slate-700 dark:text-slate-300 font-medium">
            {report.aiReasoningSummary}
          </p>
        </div>
      </div>

    </div>
  );
};

