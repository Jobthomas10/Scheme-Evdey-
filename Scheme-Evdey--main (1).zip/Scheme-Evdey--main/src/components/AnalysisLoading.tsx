import React, { useEffect, useState } from 'react';
import { ShieldCheck, FileSearch, Calculator, CheckCircle2, Sparkles } from 'lucide-react';

interface AnalysisLoadingProps {
  onComplete: () => void;
  lang: 'en' | 'ml';
}

export const AnalysisLoading: React.FC<AnalysisLoadingProps> = ({ onComplete, lang }) => {
  const [currentStep, setCurrentStep] = useState<number>(0);

  const steps = [
    {
      titleEn: 'Understanding your profile...',
      titleMl: 'നിങ്ങളുടെ പ്രൊഫൈൽ മനസ്സിലാക്കുന്നു...',
      subEn: 'Extracting family composition, income bracket, and location factors.',
      icon: ShieldCheck
    },
    {
      titleEn: 'Reading official scheme documents...',
      titleMl: 'സർക്കാർ ഉത്തരവുകളും നിബന്ധനകളും പരിശോധിക്കുന്നു...',
      subEn: 'Cross-referencing 40+ Kerala welfare guidelines and Union Ministry schemes.',
      icon: FileSearch
    },
    {
      titleEn: 'Calculating Benefit Potential Score...',
      titleMl: 'ആനുകൂല്യ സ്കോർ കണക്കാക്കുന്നു...',
      subEn: 'Evaluating confidence percentages, document readiness, and application order.',
      icon: Calculator
    }
  ];

  useEffect(() => {
    const timer1 = setTimeout(() => setCurrentStep(1), 1200);
    const timer2 = setTimeout(() => setCurrentStep(2), 2400);
    const timer3 = setTimeout(() => {
      onComplete();
    }, 3600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onComplete]);

  const progressPercent = Math.min(100, Math.round(((currentStep + 1) / 3) * 100));

  return (
    <div id="analysis-loading-screen" className="min-h-[75vh] flex flex-col items-center justify-center bg-[#f8faf9] dark:bg-slate-950 text-slate-900 dark:text-white px-4 py-12">
      <div className="max-w-lg w-full bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 text-center shadow-lg relative overflow-hidden">
        
        {/* Animated ambient background ring */}
        <div className="absolute -top-20 -right-20 w-48 h-48 bg-[#00685f]/10 rounded-full blur-2xl pointer-events-none" />

        {/* Central Pulse Icon */}
        <div className="relative mx-auto w-20 h-20 mb-6 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-[#00685f]/20 animate-ping" />
          <div className="relative w-16 h-16 rounded-full bg-[#00685f] flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-8 h-8 text-white animate-pulse" />
          </div>
        </div>

        <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-2">
          {lang === 'en' ? 'Analyzing Family Benefits' : 'ആനുകൂല്യങ്ങൾ വിശകലനം ചെയ്യുന്നു'}
        </h3>
        <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium mb-8">
          JanMitra AI Reasoning Engine • Kerala Welfare Gazette 2024-26
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-[#eceef0] dark:bg-slate-800 h-3 rounded-full overflow-hidden mb-8 p-0.5 border border-[#e0e3e5] dark:border-slate-700/50">
          <div 
            className="bg-[#00685f] h-full rounded-full transition-all duration-700 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Step List */}
        <div className="space-y-3.5 text-left">
          {steps.map((step, idx) => {
            const IconComp = step.icon;
            const isDone = currentStep > idx;
            const isCurrent = currentStep === idx;

            return (
              <div 
                key={idx}
                className={`flex items-start space-x-3.5 p-3.5 rounded-2xl border transition-all duration-200 ${
                  isCurrent 
                    ? 'bg-[#00685f]/5 border-[#00685f]/40 shadow-2xs' 
                    : isDone
                    ? 'bg-[#f7f9fb] dark:bg-slate-900/50 border-[#e0e3e5] dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    : 'opacity-40 border-[#e0e3e5] dark:border-slate-800/40'
                }`}
              >
                <div className={`mt-0.5 p-2 rounded-xl shrink-0 ${
                  isDone 
                    ? 'bg-[#00685f]/10 text-[#00685f]' 
                    : isCurrent 
                    ? 'bg-[#00685f] text-white animate-bounce' 
                    : 'bg-[#eceef0] dark:bg-slate-800 text-[#505f76]'
                }`}>
                  {isDone ? (
                    <CheckCircle2 className="w-4 h-4 text-[#00685f]" />
                  ) : (
                    <IconComp className="w-4 h-4" />
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">
                    {lang === 'en' ? step.titleEn : step.titleMl}
                  </h4>
                  <p className="text-xs text-[#505f76] dark:text-slate-400 font-medium mt-0.5">
                    {step.subEn}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Preview Footer */}
        <div className="mt-6 pt-4 border-t border-[#e0e3e5] dark:border-slate-800 text-center">
          <p className="text-[11px] text-[#00685f] dark:text-teal-400 font-bold">
            Generating Benefit Potential Score (0–100) & Clause Citations...
          </p>
        </div>

      </div>
    </div>
  );
};

