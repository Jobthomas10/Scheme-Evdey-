import React, { useState } from 'react';
import { UserProfileSummary } from '../types';
import { User, ShieldCheck, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';

interface ProfileTabProps {
  profile: UserProfileSummary;
  onUpdateProfile: (updated: UserProfileSummary) => void;
  lang: 'en' | 'ml';
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  profile,
  onUpdateProfile,
  lang
}) => {
  const [formData, setFormData] = useState<UserProfileSummary>(profile);
  const [savedMessage, setSavedMessage] = useState<boolean>(false);

  const handleChange = (field: keyof UserProfileSummary, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 mb-8 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#00685f]/10 text-[#00685f] text-xs font-bold mb-2">
            <User className="w-3.5 h-3.5" />
            <span>Family Profile Parameters</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            User Demographics & Criteria
          </h2>
          <p className="text-xs text-[#505f76] dark:text-slate-400 mt-1 font-medium">
            Update your family profile attributes to recalculate benefit potential scores.
          </p>
        </div>

        {savedMessage && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 px-4 py-2 rounded-2xl text-xs font-bold flex items-center space-x-1.5 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Profile Updated & Score Recalculated!</span>
          </div>
        )}
      </div>

      {/* Form Card */}
      <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 border border-[#e0e3e5] dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          
          {/* State */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              State
            </label>
            <input
              type="text"
              value={formData.state}
              onChange={(e) => handleChange('state', e.target.value)}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
              required
            />
          </div>

          {/* District */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              District
            </label>
            <input
              type="text"
              value={formData.district || 'Thiruvananthapuram'}
              onChange={(e) => handleChange('district', e.target.value)}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
            />
          </div>

          {/* Annual Household Income */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              Annual Household Income (₹)
            </label>
            <input
              type="number"
              value={formData.annualIncomeRupees || 0}
              onChange={(e) => handleChange('annualIncomeRupees', Number(e.target.value))}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
            />
          </div>

          {/* Ration Card Type */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              Ration Card Category
            </label>
            <select
              value={formData.rationCardType || 'Priority Household (PHH / Pink Card)'}
              onChange={(e) => handleChange('rationCardType', e.target.value)}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
            >
              <option value="Priority Household (PHH / Pink Card)">Pink / Priority Household (PHH)</option>
              <option value="Antyodaya Anna Yojana (AAY / Yellow Card)">Yellow / Antyodaya (AAY)</option>
              <option value="Non-Priority Subsidy (Blue Card)">Blue / Non-Priority Subsidy</option>
              <option value="Non-Priority Non-Subsidy (White Card)">White / Non-Priority</option>
            </select>
          </div>

          {/* Children in school */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              Children in School
            </label>
            <input
              type="number"
              value={formData.childrenInSchool || 0}
              onChange={(e) => handleChange('childrenInSchool', Number(e.target.value))}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
            />
          </div>

          {/* Occupation */}
          <div>
            <label className="block text-xs font-extrabold uppercase tracking-wider text-[#505f76] mb-2">
              Occupation
            </label>
            <input
              type="text"
              value={formData.occupation || 'Student / Unemployed'}
              onChange={(e) => handleChange('occupation', e.target.value)}
              className="w-full bg-[#f2f4f6] dark:bg-slate-950 border border-[#e0e3e5] dark:border-slate-800 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-medium focus:outline-none focus:border-[#00685f]"
            />
          </div>

        </div>

        {/* Submit */}
        <div className="pt-4 border-t border-[#e0e3e5] dark:border-slate-800 flex items-center justify-end">
          <button
            type="submit"
            className="px-8 py-3.5 rounded-2xl bg-[#00685f] hover:bg-[#005049] text-white font-extrabold text-xs shadow-md transition-all flex items-center space-x-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-white" />
            <span>Recalculate Benefit Potential</span>
          </button>
        </div>

      </form>

    </div>
  );
};
